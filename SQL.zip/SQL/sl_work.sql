/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.150.101-mysql
 Source Server Type    : MySQL
 Source Server Version : 80029 (8.0.29)
 Source Host           : 192.168.150.101:3306
 Source Schema         : sl_work

 Target Server Type    : MySQL
 Target Server Version : 80029 (8.0.29)
 File Encoding         : 65001

 Date: 17/09/2024 16:54:37
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sl_fail_msg_bak
-- ----------------------------
DROP TABLE IF EXISTS `sl_fail_msg_bak`;
CREATE TABLE `sl_fail_msg_bak`  (
  `id` bigint NOT NULL,
  `msg_id` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '消息id',
  `exchange` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '交换机',
  `routing_key` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '路由key',
  `msg` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '消息内容',
  `reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '失败原因',
  `created` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `updated` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `created`(`created` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '失败消息记录表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sl_fail_msg_bak
-- ----------------------------

-- ----------------------------
-- Table structure for sl_pickup_dispatch_task
-- ----------------------------
DROP TABLE IF EXISTS `sl_pickup_dispatch_task`;
CREATE TABLE `sl_pickup_dispatch_task`  (
  `id` bigint NOT NULL COMMENT 'id',
  `order_id` bigint NOT NULL COMMENT '关联订单id',
  `task_type` tinyint NULL DEFAULT NULL COMMENT '任务类型，1为取件任务，2为派件任务',
  `status` int NULL DEFAULT NULL COMMENT '任务状态，1为新任务、2为已完成、3为已取消',
  `sign_status` int NULL DEFAULT 0 COMMENT '签收状态(0为未签收, 1为已签收，2为拒收)',
  `assigned_status` tinyint NOT NULL COMMENT '任务分配状态(2已分配3待人工分配)',
  `sign_recipient` tinyint NULL DEFAULT 1 COMMENT '签收人，1本人，2代收',
  `agency_id` bigint NOT NULL COMMENT '网点ID',
  `courier_id` bigint NULL DEFAULT NULL COMMENT '快递员ID',
  `estimated_start_time` datetime NULL DEFAULT NULL COMMENT '预计开始时间',
  `actual_start_time` datetime NULL DEFAULT NULL COMMENT '实际开始时间',
  `estimated_end_time` datetime NULL DEFAULT NULL COMMENT '预计完成时间',
  `actual_end_time` datetime NULL DEFAULT NULL COMMENT '实际完成时间',
  `cancel_time` datetime NULL DEFAULT NULL COMMENT '取消时间',
  `cancel_reason` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '取消原因',
  `cancel_reason_description` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '取消原因具体描述',
  `mark` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '备注',
  `created` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `updated` datetime NULL DEFAULT NULL COMMENT '更新时间',
  `is_deleted` tinyint NULL DEFAULT 0 COMMENT '删除：0-否，1-是',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `order_id`(`order_id` ASC) USING BTREE,
  INDEX `created`(`created` ASC) USING BTREE,
  INDEX `task_type`(`task_type` ASC) USING BTREE,
  INDEX `courier_id`(`courier_id` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '取件、派件任务信息表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sl_pickup_dispatch_task
-- ----------------------------

-- ----------------------------
-- Table structure for sl_transport_order
-- ----------------------------
DROP TABLE IF EXISTS `sl_transport_order`;
CREATE TABLE `sl_transport_order`  (
  `id` varchar(18) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT 'id',
  `order_id` bigint NOT NULL COMMENT '订单ID',
  `status` int NULL DEFAULT NULL COMMENT '运单状态(1.新建 2.已装车 3.运输中 4.到达终端网点 5.已签收 6.拒收)',
  `scheduling_status` int NULL DEFAULT NULL COMMENT '调度状态(1.待调度2.未匹配线路3.已调度)',
  `start_agency_id` bigint NULL DEFAULT NULL COMMENT '起始网点id',
  `end_agency_id` bigint NULL DEFAULT NULL COMMENT '终点网点id',
  `current_agency_id` bigint NULL DEFAULT NULL COMMENT '当前所在机构id',
  `next_agency_id` bigint NULL DEFAULT NULL COMMENT '下一个机构id',
  `transport_line` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '完整的运输路线',
  `total_volume` decimal(32, 10) NULL DEFAULT NULL COMMENT '货品总体积',
  `total_weight` decimal(32, 10) NULL DEFAULT NULL COMMENT '货品总重量',
  `is_rejection` tinyint(1) NULL DEFAULT NULL COMMENT '是否为拒收运单',
  `created` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `updated` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `order_id`(`order_id` ASC) USING BTREE,
  INDEX `created`(`created` ASC) USING BTREE,
  INDEX `status`(`status` ASC) USING BTREE,
  INDEX `scheduling_status`(`scheduling_status` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '运单表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sl_transport_order
-- ----------------------------

-- ----------------------------
-- Table structure for sl_transport_order_task
-- ----------------------------
DROP TABLE IF EXISTS `sl_transport_order_task`;
CREATE TABLE `sl_transport_order_task`  (
  `id` bigint NOT NULL COMMENT 'id',
  `transport_order_id` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '运单id',
  `transport_task_id` bigint NOT NULL COMMENT '运输任务id',
  `created` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `updated` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `transport_order_id`(`transport_order_id` ASC) USING BTREE,
  INDEX `transport_task_id`(`transport_task_id` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '运单与运输任务关联表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sl_transport_order_task
-- ----------------------------

-- ----------------------------
-- Table structure for sl_transport_task
-- ----------------------------
DROP TABLE IF EXISTS `sl_transport_task`;
CREATE TABLE `sl_transport_task`  (
  `id` bigint NOT NULL COMMENT 'id',
  `truck_plan_id` bigint NULL DEFAULT NULL COMMENT '车辆计划id',
  `transport_trips_id` bigint NULL DEFAULT NULL COMMENT '车次id',
  `start_agency_id` bigint NOT NULL COMMENT '起始机构id',
  `end_agency_id` bigint NOT NULL COMMENT '目的机构id',
  `status` int NOT NULL COMMENT '任务状态，1为待执行（对应 未发车）、2为进行中（对应在途）、3为待确认（保留状态）、4为已完成（对应 已交付）、5为已取消',
  `assigned_status` tinyint NOT NULL COMMENT '任务分配状态(1未分配2已分配3待人工分配)',
  `loading_status` int NOT NULL COMMENT '满载状态(1.半载2.满载3.空载)',
  `truck_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '车辆id',
  `cargo_pick_up_picture` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '提货凭证',
  `cargo_picture` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '货物照片',
  `transport_certificate` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '运回单凭证',
  `deliver_picture` varchar(1000) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '交付货物照片',
  `delivery_latitude` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '提货纬度值',
  `delivery_longitude` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '提货经度值',
  `deliver_latitude` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '交付纬度值',
  `deliver_longitude` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '交付经度值',
  `plan_departure_time` datetime NULL DEFAULT NULL COMMENT '计划发车时间',
  `actual_departure_time` datetime NULL DEFAULT NULL COMMENT '实际发车时间',
  `plan_arrival_time` datetime NULL DEFAULT NULL COMMENT '计划到达时间',
  `actual_arrival_time` datetime NULL DEFAULT NULL COMMENT '实际到达时间',
  `mark` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '备注',
  `distance` double NULL DEFAULT NULL COMMENT '距离，单位：米',
  `created` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `updated` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `transport_trips_id`(`truck_plan_id` ASC) USING BTREE,
  INDEX `status`(`status` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '运输任务表' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sl_transport_task
-- ----------------------------

-- ----------------------------
-- Table structure for undo_log
-- ----------------------------
DROP TABLE IF EXISTS `undo_log`;
CREATE TABLE `undo_log`  (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `branch_id` bigint NOT NULL,
  `xid` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `context` varchar(128) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `rollback_info` longblob NOT NULL,
  `log_status` int NOT NULL,
  `log_created` datetime NOT NULL,
  `log_modified` datetime NOT NULL,
  `ext` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `ux_undo_log`(`xid` ASC, `branch_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of undo_log
-- ----------------------------

SET FOREIGN_KEY_CHECKS = 1;
