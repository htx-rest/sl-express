/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.150.101-mysql
 Source Server Type    : MySQL
 Source Server Version : 80029 (8.0.29)
 Source Host           : 192.168.150.101:3306
 Source Schema         : itcast_auth

 Target Server Type    : MySQL
 Target Server Version : 80029 (8.0.29)
 File Encoding         : 65001

 Date: 17/09/2024 16:51:34
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for itcast_application
-- ----------------------------
DROP TABLE IF EXISTS `itcast_application`;
CREATE TABLE `itcast_application`  (
  `id` bigint NOT NULL COMMENT 'ID',
  `code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '编码',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '名称',
  `status` bit(1) NULL DEFAULT b'1' COMMENT '状态',
  `describe_` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '描述',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '路径',
  `color` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '颜色',
  `logo` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT 'logo图片',
  `create_time` datetime NULL DEFAULT NULL,
  `create_user` bigint NULL DEFAULT NULL,
  `update_time` datetime NULL DEFAULT NULL,
  `update_user` bigint NULL DEFAULT NULL,
  `last_use_time` datetime NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `index_app_name`(`name` ASC) USING BTREE,
  UNIQUE INDEX `index_app_code_tenant`(`name` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '应用' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of itcast_application
-- ----------------------------
INSERT INTO `itcast_application` VALUES (981194468570960001, '1653976591227', '神领物流', b'1', '神领物流开发环境', NULL, 'default', 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANwAAABGCAYAAAHQoMoyAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAA3KADAAQAAAABAAAARgAAAADSHK/uAAAePUlEQVR4Ae1dCZwU1dGv3ZnZ+74PFo1GjcYYNd5Xohg10agxioqKSLxFQEQ8IqiIIKIoKIiKgopiEs94E+OtMfHMp4lnjMLCsgd73+dX/+qp3p5mZnZ2bcbZpev3m+nu916/fle9o169f8V9e9I+fRRFio/it+RTYT84+k//oMyx5ziaprhgRZo14RLK+PUp1NfTTXEer3xw7dh9CQlQanrhz5Sy76HUXV1B3vxi8mTnqZcZPsDB/xA0h/gYSD/mDxtwqbvvZvlI4o4/2fxjpx0ckDjri0FzGJeSSqkH/JKaX3rSfBE5dIKC5rCvtYVyzr3S/Fhfd7d8q+zht8xvZp50No164BV5jktMIiRSizx38mzycDEHo6A5DBbQKbegOXQq8mDxRDWHUc1dyI/lXTLXrPxgRTIUt6AfQwtL2X8MKYPHJSRS6fIXJX74FVyzVBKC++S9DD7DPVpnOAr6MX0BEYD6OjvIk5Fl5rTqugs1CKWNOd68B/t4C0rMcKaH/yZkAyn74ztE6Ma8PgnqBJMbHaItCZojsnwoPjWdCq+/mxoeW0F93V3S4/TU1ZAnJ586PvsXpY45jtrefY0aHllGhXOWk7doFK0/+6iAmEPmLCCUQw9h68yhb5jRRDVn5lejdBPVkoxSnszPBGUA09d2U3jDvZS4w642V+Oxat4l1P7h26Zf/tWLqXrOZHkuXvwoVUw+UZgCnaGdNl4+nig+nooWPCQcvnHGGRIkLiWN0o86iRofX0Hx6ZlUcvvjVD5hjP31kM8RN0uT4/1RBetaEEbdcb+BM1TCGVNqePReav/PB5S0y56UeeLvqfN/n1PCD3Yy3on30OhH+gsH72gn3dPcQHG+RI2Gys/4uXkf7ibiZll+1uEB8SDx9l9vR3tAmO6N66hz7X/FrfHph7jbu5e8uQWSsXXjf8G9fS+1vvdGwDvBHlpff0EyFM9zIPwipYgzV3rfX8042/71jpRq3f23mW64qVtxi/nc+s9XKe2IE2jj9HG09pT9qf7Bxdzkeij3omvk3b72NvJtuyPV3DSd8qZxU+3tkbkzaquP70Flj/yd0NzTf30yYTKHCeC60w+hrDOnmt8JdxNxs9RIUg44nPKm3qCPcl077iAiHohijQaduVjLQLj0RNwsw0USq35uzcVqzQyUrhHdLEd05gY1/UIziOcV1ij/kq6vq5PWsbgkVmlQNYcZiWYMGYrzJZizFGsGMa9USj3sWL2lovkPyA8Oep83fb74Fy9cHXDVMOLIf6NW/k1vI75GnDlkzEobLj7B+hiwDk7Ydicz0968IvKO+gEl7b6fzCMrZ54j73mycslbPJpqbr5cwvpGbUdpPEnGVad1vW0tlPDDHxMm3huvmBDwvUgeIhsKvF4abZF5tX/yLlXNnsRL4gLqqa2S7/hG/5C61n4l9/aCgGPV3CkUl5hMfW2t1NvazIneheJ4sowpWsXUsZIhnShLJPzX/LenqH71UipZ8pQ6ydXZiXNvb0DkSbvuLYkpvu1PZinHp2UEhOniSTOojueU5RN/Kfdt/3iFEn+8J68GPpNnT44hWzULw+MhzFfrHlgk/vWr72TB8HkyWe788mOZPNfccrn4RfIXWbO0ZU4jjk9K1lsqvPZO876VM4H1G1YEGb85jQquXUbtH70jBZH52wkygc6ZOJ0yjj1Dak2XSUm77SsC5aZnDf4btfwFqltu8KRGHpeUorcDXiNqlughexvrJbKC2XdRx6cfSZMpveOJgA9oIgMcv8eHiGoOGVMm92TlUU/9Juqp2hAy2ViqQIyVPWEalT38pvSM2HdI3HUvyho/hSBT83BHg2WMUv4fFvFKvUzCq9uoFS/Jd81n7jHLbAta9Qt2jShzeLF6wQx538fys5yzLg34KDystSZNiZdAKQcavAZ/H/egoDZenNaDp+LiKIV3B0AYLpJ+so+ISLVTgjtke61/N4aAuORUav3na1S7bHMxBcIGo4iapfVFlHocJ0yp44uPqfLqs/Uxpq6DzlxMpX6AxETcLAeIJya93czFZLVEkKgRzXMR5H/YBhnRLDdsayWChLsVF0EhxWIQt+JisVYiSNOgJV8RxGkG8ZZsQyW8Uo+EsIu//ryjIwnqhuES2CKTk9J7nidPZk7YAu5jqUXbB29Syl6HbBZu09LrqeXVZwLcsdMMLRdIErG866osp8zjzwwIow+QQ/nKtqfsMyZTx5efUHxyigjUsNyENBGEzdyehlqWbVWLqpwK4DZM4Y3gRcZGMMKraKfRL/XQb9SzmEf9rOHU3361LnXtfkN5dpzjNDP2xEAuvWHy76hnkyEEtPsn7/NzSjv8t5S8+/6Ue+FM3lSeSBsm9UtFa269ihK235mK5q3k5kbU8PBSs+IgW0MlQb42yr/3i2cIQnyl21LdyoUc5ywRYKDCusq/praPWAjCESWzJLW3uZHSjzlV3LLPmm4mDWpTm5ZcF6COmDXuIvFHxSl5eBN83YTDqGzly/JNNDylgqtuM/eI1c2Jq6MVFx+Gy8AppXc+LWlWmYSdM5vWPBYghLFmMOP48aSFlrLfGMrhilCC2Brk5Uqykrqj0kDJe/G+NlPTmscJMsXGvzwoFYeCb3pmtfxwr+n0Fo7ib15I7f9+n5J+/DNq//RDeV//wEWZp5xPyXscyCqihgiw5rY/iCYDhLrKZdU3TtNXHLs6Ojnp5a4nEoJSLTjT3p2mH/E7cRc/LkArNT75AEHIC6qE3h6r2Skl7210t3lT54hTd02lCILRHaPwwFEgVA4IXA1KP+Y0ueKvYNYSFulzj1C3yXRDxYJa3nhBrrV3GvHLA/9BDJl5wlnU/PJfKOWgI8S54z+Blathnb46WnFIHAoK6iZQ9rFTxTRWz/arltj97M/a6u3ueO5gDqi9a67xLf5e81+N1r7hgmPFrbv8f6L20tvSJA0B2xcoXKUkrjikE90vCFxSNfsiamaOt1LO2YaINvN3E8W5YNZSudatvJUgzU/+6X7U8iZrnXKe0n91svVV8x57PQVXLRKtLtPRgRvHJyfgFrT4qjmTqHvD2rBJhN586V3PhgyjXU3IAFuxh+McV87Kt968Ql4G/Nns9lCZ+Pl4WzXjtxNM91CVBq24YJWGOBK4m8XOCnYqsbsCwg5LCW8z6YxRT3hgtwXf8JVtx7rWaZT4o90p5eCjZOclmQ9e4B0lUTrzP+i+dPEiPqDBExTfNjtQzvkGdyINIOzwYEIDsupWYkcneb/DeENkB/Ej3mjEvoN9/DU8h/7vOMdpUqBZXboscEqvfqGu0ACsvmFKKG/X3VICW6ziLN8wbzHrxEwP6yqsoborec8ywjHPjMS9kRJwdDkwUJli1hnpzHOguLZ2f8fHuK29QKOVf7fiolXSDn8nqmOcw2nfqqNzOW6YVr9bcW7FDdMSGKbJdjnOrbhhWgLDNNkux7kVN0xLYJgmOyoiL2xQArfHvnGKQ/04StD5tXGEZ5iW4feS7C26AC+YeQef59g7oozVLJ5JrW+uiSisG2gLaXnFZ2TzGU9ju38whYzjjOVnHhb0FXAtFIrq7l1A3RXGATwNiOOPLa88Q41PrFQnc29OHTbdfo0AOSRsv4s6mVfBJfE/6RnSimm818Z7acULVlEXbwhDC8xKhfNW8gnGeLK+C//Se9cwJpqHNi2dTW18wGhLkeMcF+k+XMtbayj1QENPw545+yYqzrSmHXqsbGr2drZT+/tvCcRI8c0P21+VZ7yPDc/umo2sQ1IjIDTAW/Fk5bCm2C4EhSAPNy5groBQ+KMeeJWsBxoRR9qvxsqpsvbPPqLO/34qYfHX9v6bDCvlFZWETctuEO20RD6KGoo6vvoPVV51VijvIbk7PsYNtHkK3Y9aziwOGYequJKlT9GGC48zM4SzvYmsZQWOjOejcih40dHjfygOFTLCGLSsoN5nJRxrBXIQdt6x4929/n+yHxiXYGDCYH+wftVieQWV1tfXZ56Qw845ILdASbxzjp+SKBT59xFzz/+DsVvPXDZ69duEhlV+emRgOhrfUK6OLgdUfS5YQppefFQyiEoDQaEHrRq/9Rceyxx0H0H3EoTT4zj7qNTClb3+7CNFQQdu1uOGvY11EqyXsW+UAFoIamXtLEAwtbzxIiWw+kJ8WqboSHYwB0GvEpWVN9nQgcRzO+/AK3V++yVtuOh4qn94CVVcdrpca+64Vr3NSsXYDCq9+3m51iy8ik+97y8/qFeA8zF0OE2OVhx0H0NR+pEnUuIue5je0AEh1rUE9bByUcMf7xIgB1QkwOTskxrofuh5UUPvo0/eLb7FULnLOGacPOMP3TW6RlDt3TdS09OrzGe44dw2ZrhWxdXquVMJPyXcAxMQjREn8nHtre9XP2xmwFBQ7gUzpTEAZxC6MtA/ybv0RvllnTFF3HIvvlbCOvnneFcZLnGFfNgdBBVxPfSu4TEWVV5zPgEuq3LWuQEchzCqkAOEKIwvStU3z6D86TdRy+vPUeohvxbnhG12FKVUYIdZqf2T9+QRFQuN5nCExrHpjuskCJRhQb0tjXLVP2hQ48Qz0t7HlQbMRjQ8vFvLwKw4xA/FqS2hR9NfApqa73CFAipmWgMR9AztBFU9gLdBbXz9uVwBPN4oAdtVqe39NwQaF+MeSGeYPX6AAbi1vvM3KUDcg1CQAMMMRwYX94dA41KQTJxZCEZZp02S/AJiEpUWTRq4lAeRmmrGVvuuBGWiUttSovbueQEVAaCQxB13lU/lnGeozaWwSpyVoD6XctCRplPjc4+Y9+kMdQECop9SG3ef6y/4jT5Kj5C854HyHB8CygKN1Kr4i3ExWuRoxbV/8BZ1bSz/zmnHVB1jRiiCFjPUwoE3ovggQInp+OrftM6/DsQpnDzWcYQeJ6jpL6tEWxkHPjBWdjLqDAD60LWBqpnD7AdScN4B4UBdPJnSNWAfzxxTf250y9qdIkwnnwyKFjlacUh0BZ/IqeeTNHaC/n7L68bMy+4X7Dlpt32COZtu6CKBrogfqOW1Z3mtNJEhflrkuWLqSXLNOvUCucqJHB5zgF+EbnDjdIPryh56Q/xD/QHhA9T63usElXSMsZiYaPeNxqrU8eW/9Vaum243DpvYu+GAQEN8cHQBnv37y0SyoWnx8MCcwWfYUvY/nDyMiKqtG5lOO/x4DRb0WrN4FovAXgzq5zry3C0Yfv5QCwaq2/E8zW94YiU18OJ3IMo+53JK/+UJQYPhgKFOPIIG2ModHe0qN/pxeIBrhe4Bv7JVrxPkerlTjIUuyluw1VkyEarSEMZeacCuU9Qk7XqKbn4IQQnAYtkMeARSvX/caxpwD5i3gll34LbfndHSlAA8LgS4YU43pDegNF5/wjoBIOFSWEQXz5MngCHBDff6DchSi268v/+d1ezPa8Wimx6UswPi4eCfoxUHaUi3H3ZO04hKSuSTpBBvYSIBMHxUpt3ChYbHtcI//ljdsDzoZJlfMOrkSYmKp+z+sKgByh4/1Zxc4Bndth6jwrNS1vjJtPbk/ajj8/8Tpxx0//ctEOBsDUO87OnlY2TQykY8OK5sPaKFd9adeqChtc0Nof3jf5qvOnXjaMUhURvO/41IC4IlsIztaAy03oHQ1grpZcbD0M6oBMB64WQoOKj943fFG5IWoNkJ8YzRiiYJURqoi+WUItLymwLI5UOQzS8bXAV/SFLwXstrz1HOeVfyWvEwOMu6spfXgIk/+qk84w+yT0hmUg/tXz6YnnyDtWjKIb9iEVuG4CfG4eyzw+ToGGdNW96Mm/lgfvCFqzWc9R5nxLsdWE5Y4xyp91us4qTAWGJewMdtcR46HNXwXhkEwi5FXgJbtuJs6QBsY3xGJoufOqX/h4zPpaGVgKOyyoGSAAEy+eFjBwrr+ocvAccnJ+E/5/o6VQJuxTlVklGOx624KBe4U59zK86pkoxyPG7FRbnAnfqcW3FOlWSU44nqOi7KeXM/55ZAzJWA21PGXJW4CRrJJeAy3EiuXTdvMVcCLsPFXJW4CRrJJeAy3EiuXTdvMVcCLsPFXJW4CRrJJeAy3EiuXTdvMVcCUdUSimbu4/l0CQ4w4NxVXFKSWOXGAXGcjerjaw/OA7sI3tGsEvdbXALDnuES+ERq+pEnEU6i4gDiUAkYJM1rHqXWt18a8LjxUL/hvueWwPDb+GamAo4bUDHi/Oc2tkQ1wuJY7T3z2SzQt1siejfOrbQEhg3DATiq4IqF5C0oiWpVwVha3YqF1Mx4SJGSj5FTiv2GPPEOzAvWLZ9vvg58IfsBaphpgs1IEE7ktX34thkeNzhM3V21gU0WHkL5MxYE+NkfFH8QlvCS2BxUJNTFHUvF1LESFKYUfSWj5b5uxS2GbUxLJHoQHHA9RXNXmD7NrzxNdst6pqflJo/Tr4ZVYSAOFnEBYoJzXQlqQsoSHmg0cZajpzDohp+dOr/5kmocwPuwx+vkc+wzHI9ihbPvokQ+v/tdCIyDRtvw+AoxZge7Yr5io1FFEi/AxSpnnhMWCRUnLGG3MxxVL7xSRs1QcH+h3lUIJivagRXVwMMdUanflhpQeQAkZqesM6dSxtGnijNMUNavMs5TW8OhQ1ObbCiz8vGHyrFhaxhlOJwJD4WeZw2v93X8vSa/6cvixY+Rr2iUeAG6ELCFgIPyZBu2UhN33oMUXAaBOhiysI3zFY6AiAdYqVimmF7DxTOmZOmSp4a0NsM5cJihbnjifurxn/3WisBoAgCZ7oq1jL+VIcd8cXwYx31DEdaHOJBfy+CmoUY7YJ4oIBviyZ10jYkphueNV/+eOr/4hHyjt8ejSRWXnioIe7CeDGp85mFq5I5BrSqbAfkmac8DzMcuBuVR8IIKbrAYGRN32k1GQWKko4Krbw85wgFbDD8lMCgYFaAEShhVcEbfTvgm8Gtq75onP7u/PidstxMpZpu64Vq88BGT2fAMLLWci2ZR7ZLZeJSj4VZmq3vgNtOmrQTw/8Goouah65svqPGpB63eMXkf0wxXfNOqQTMbQA/qgMntB0oIVuqAqMRvIAIYXsoBhzPi09EMF8ZWPZkAooD1HUAlwlHh7LsDzvgbaFHBz+2jkQMDQAnTqmBYALDy6fXjzQF7HLgGwCoAlkAqWw1teeN5YTisbZP36GdMxAsAP2tnALfUXxwjZtZxn3nKecJwQES2oiITEEMeCZze6giH90rvfk7wWnEPrAVgrSrhm8EIHU/psmdNEF6ATCmzAVHSjpgJkAz8whFAeTuZ6ayAF+HCf19+MctwGG3U5PpgCgfgvUXX32O+0s6WuBseXU4dfnRKeCQw0krRvJUSBlsF3ZXl3Hj/Kw0YKJaKuIz1BYxTq4FqvAAQDV/ptqEZjht7CUPk2NeaGO1AaJRAYrESrIdbCfAGwSAOAMuNdZJSzgVXUxeP0vihcwAsnPoDDsdOWadfzCPC6eKMKWUHj7ZDoRxmKnRsXd9+ZdYRTvBjraUE46mhYOj6WlsEhbSY4XpAqQwmAjg8WHcHBm/96qUaTT/gJQOfmOQHwQRYimIHY6tnOGzzxCzDAZbOCUpi/OAkFh4oQfwPBlQIWQAxJ/DIgZ+dZN3H2wT1DP2qkBAAhA5FaORARwXCt5U6vvjYHCGBj1W94DKrN0U6pcTeIjqUYGTvoKydRLDw4dx8o3/I09KDZWqKzslOadzpAIDGawGuaX339QAgG4UZtL+rz5gCAhcFHQUI0ExC3GGNZnvgSgp2UzAT0+O9xVlHa+A4A3IXpGtceYjhv9hluPZWwfNP/tlBjhYfph6QdkZCWMOkMqosfmC+qjmTA0ZKexxgtI1XGqNV9sRLKXm3fSUImBUw/Wio3sLSgHWSPQ591oaoz8Aua//XP6hi2immk/UGoHTJDAIHAkSWfRSFe7wFbhgI8MHIPhXGNC1h2x0DguqUssgPXA7Pzq8/pXRGeVdqffc1vQ16hZRWMT4RoOr6SRIucYd+4VhPU8OIQ5aKWYZD6VfPv5TymTmsC2iple/hD8xXyCMlcNpql80NmgLB2/H79LW1BoSBeQU1sYARBCOdkiLu6zP2GK3o+1ivgdlAqb84mtddBtCsGgwBEytzIwxQi0GQyDa/9CR5S7bZTHoK5gcaMUaLXsYd7+UODlR5HQPoMr6dSUHWcPDDN2G6AQSRvhV5GQKrdjbbEApYHp0JMGiVMA1W/LwEywgeakqq7w3Ha0wzHAq0+sZpDN+ZQ3lTbwjAKA9X2DCKEudNiAg4P1w8wfzSDjtORitIG4dKEHboKKFxAIfdKqWEMbZg1PIqCxtYZS17wjTeKtnFlFJqWOynwdIPCOvWvGlzWQtnjDwDn33jjPGiMFB040qJB9sYtbzX1vr2XyVMALMZLkH/sR+o1PbBm2SdibQxKnX+ZQsC3GDIoP0jQ/iSc9E1bCbKaHrYT4OCgZJ1yox1YjjqYUtJOqXM5z08rLkrLjmZp6eN4V77Xv1ifx/OVjyAlIWBGkzz7FMda1CYBoEEz8t7PcCrx8JcK9kabij3EHyEW8shTh9LGtWqIQQIXbwpG44Aj+vJL5YgmILatzLs72LfLZ7txdgJe1GAqQUl7rw7zyM9cg8oeLs1RWATq9EhfDOUVk2CX0IrEfFfJ69JMWrqNkp31Xry5peYAgykXbc++ni0RAeDUVSI12hiKMkfWW8Tj67MKErWNMl7PK0EoTyxhQPCdg5sEYBg1ycB2yx+Bhbps3WEllCx8xezDIcpCvaAAIlbd/9tRg9sMdESsgi5gaEhwNaOVoo1rMDnHzde1lND1b2EmbMO3hpwyS2BwZZAzDIcMgKxd1oQbGos0Ds+/5iNK37GvfbnYillUCJh3sROG3McZRzHhqVyDSlXpAUHC5sVl4ztF1eHeBE9NQcyRhWeToHQS8PiSy/32rDfFMcSUh1VsMcGs3cYaQy/JNGIkfd4zdfTWBtg8QwjvbeoVOLFH0YQ7WAwanmLywLciDsg2evr7eM0VAaMKmYkfINRFp2V3VIAwiCN8ckpkie7PSlM+32lP2B88m84nZskSqzVPPlFPMJ9bYrsMTJ7+RuQUmJkg2jfW8ijo4W0jLysXgbgYEwdlWAdwMejq4x+OnXk7ZLEHX4iNiC7omjKSNM0mGv8YAJHOyz08oJJuxK225nS2VIphAfFbB4CG7NqokGvGSdMMJOLBpjO+0+l9zxvhGPLOVi7DJrZWBReMX1cWGZTcxFJu+3N5m+/7d+PYybHRj5MFYLA7FhfKRXNW0HFix4VoYj4TZmjXqLals6mJ6wEPUbEB8J0VZkNz1g/YW+vZMmTptjdk50v4cGIEPXDrpddnxPvYh2Zy2ssK0G4gnL1ZGZL5wbVLwD9g8CgMJOB73WwcAcWZ5VgoxJpVOloARs/zZ8+XzRidPqMqS7Sj/dzzrlC7tEhgWA3M2vchXKPmYl8h437dLAUVg3OQcgCY6aegmKZDVn3AuXFGPszVq4xlihrcmoWzBA7KNCnjPR0AKahWLtANUrXGdY4h3Jfs4gNkrPJ5IEIvfvaU/YXDRUo9qIBlE88grmiM0CahymzXQEXisKwFtXLG8ORUhJvPfiKRovZEIwYKQcdQTD5BTNbkJTCyoXoVVqm4+2fvE99LKzA+nZz6tvMCRJJbIvALJcwCI9i3kLjXYyaGBEhKME6GSc5YHSvbvlNm3VMVTwV9/EWQ97F10nHA73StndeNr63+WcD0mF+50M2E8Z5wQgHgiRz7WkHUxpLb4vm3y9lXDH5xIB3Y+kh5hlOCpU1M9aNO4gStvuRaJR7LRoNwQoTGipZY88N5jUoNzTg6luuCLv3Zo8QDJ7JtumSf7ovm6TpMLTn/eanK644k+32sKWuY06ThoLORAmaLjCLDSlb/pW3CrOYfqxGlrzPofKDgKLmpsvkEC0MHJr2X7lsoKGBs4G1fDKhmU8ooHHnTrpWOixMIxEe9mHTWKWrZtHV5laDfgfXbjYo7C3Zlor8ttSr5kyihj/dwyPbN1R43TLZ1IfOZT0bHQa186kG2DyCFotv9Hayb6YKxOhQ8E2d7sOsNwRe2ANsWvMYtVn26mCbva+nW+LUPxiLhIFjEGznQl8UI7BourBArI71WjEthzoY9GPR2UFBOpYpptdw4QouiY+yZE+41DxGEi7sYPy6uWFCSGP2vIN52Q3rlsAAJTBsGc6eL0yPYLgTonAoGmOvKhxh0Q+VK+hatr33mqwdwoV3/dwScKIERgzDOVEYbhxuCWzpEohpKeWWzrwbv1sC0S4Bl+GiXeLu97bqEnAZbquufjfz0S4Bl+GiXeLu97bqEnAZbquufjfz0S4Bl+GiXeLu97bqEnAZbquufjfz0S6B/wegJvRG/6+c+gAAAABJRU5ErkJggg==', '2022-05-31 13:56:31', 1, '2022-08-30 19:16:03', 1, '2022-10-18 13:53:59');

-- ----------------------------
-- Table structure for itcast_auth_menu
-- ----------------------------
DROP TABLE IF EXISTS `itcast_auth_menu`;
CREATE TABLE `itcast_auth_menu`  (
  `id` bigint NOT NULL COMMENT '主键',
  `name` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '菜单名称',
  `describe_` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '功能描述',
  `is_public` bit(1) NULL DEFAULT b'0' COMMENT '是否公开菜单\r\n就是无需分配就可以访问的。所有人可见',
  `path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '对应路由path',
  `component` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '对应路由组件component',
  `is_enable` bit(1) NULL DEFAULT b'1' COMMENT '状态',
  `sort_value` int NULL DEFAULT 1 COMMENT '排序',
  `icon` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '菜单图标',
  `group_` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '菜单分组',
  `application_id` bigint NULL DEFAULT NULL COMMENT '应用id',
  `parent_id` bigint NULL DEFAULT 0 COMMENT '父级菜单id',
  `hidden` float NULL DEFAULT NULL COMMENT '隐藏标识',
  `create_user` bigint NULL DEFAULT NULL COMMENT '创建人id',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_user` bigint NULL DEFAULT NULL COMMENT '更新人id',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `PAM_name`(`name` ASC, `application_id` ASC) USING BTREE,
  INDEX `INX_STATUS`(`is_enable` ASC, `is_public` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '菜单' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of itcast_auth_menu
-- ----------------------------
INSERT INTO `itcast_auth_menu` VALUES (101, '用户管理', '系统管理', b'0', '/users/user-list', '/users/user-list/index', b'1', 1, 'el-icon-user-solid', '', 1, 0, NULL, 1, '2019-08-20 23:35:12', 1, '2022-02-22 09:30:41');
INSERT INTO `itcast_auth_menu` VALUES (104, '监控管理', '开发者', b'0', '/developer', '/developer/index', b'1', 6, 'el-icon-user-solid', '', 1, 0, NULL, 1, '2019-12-08 06:38:34', 1, '2021-04-12 18:23:14');
INSERT INTO `itcast_auth_menu` VALUES (603976297063910529, '菜单配置', '', b'0', '/menu', '/menu/index', b'1', 2, 'el-icon-s-order', '', 1, 0, NULL, 1, '2019-08-07 23:46:11', 1, '2022-03-25 11:09:24');
INSERT INTO `itcast_auth_menu` VALUES (603981723864141121, '角色管理', '', b'0', '/role', '/role/index', b'1', 2, 'el-icon-s-custom', '', 1, 0, NULL, 1, '2019-08-10 00:07:45', 1, '2021-04-14 00:48:00');
INSERT INTO `itcast_auth_menu` VALUES (603982542332235201, '组织管理', '', b'0', '/organization', '/organization/index', b'1', 3, 'el-icon-s-flag', '', 1, 0, NULL, 1, '2019-08-06 16:11:00', 1, '2021-04-14 00:50:26');
INSERT INTO `itcast_auth_menu` VALUES (603982713849908801, '岗位管理', '', b'0', '/post', '/post/index', b'1', 4, 'el-icon-s-platform', '', 1, 0, NULL, 1, '2019-08-07 00:11:41', 1, '2021-04-08 02:12:12');
INSERT INTO `itcast_auth_menu` VALUES (605078672772170209, '操作日志', '', b'0', '/monitoring/log-operation', '/monitoring/log-operation/index', b'1', 1, '', '', 1, 104, NULL, 1, '2019-08-01 00:46:38', 1, '2021-04-01 10:09:52');
INSERT INTO `itcast_auth_menu` VALUES (645215230518909025, '登录日志', '', b'0', '/monitoring/log-login', '/monitoring/log-login/index', b'1', 0, '', '', 1, 104, NULL, 3, '2019-11-19 18:54:59', 1, '2021-04-01 10:09:52');
INSERT INTO `itcast_auth_menu` VALUES (829717676565049825, '应用管理', '', b'0', '/adhibition', '/adhibition/index', b'1', 5, 'el-icon-menu', '', 1, 0, NULL, 1, '2021-04-08 22:01:50', 1, '2021-04-14 00:47:35');
INSERT INTO `itcast_auth_menu` VALUES (834002593268115937, '首页非官方', '', b'0', '/dashboard', '/dashboard/index', b'1', 0, 'el-icon-s-home', '', 1, 0, NULL, 1, '2021-04-20 17:48:33', 1, '2022-09-02 14:44:57');
INSERT INTO `itcast_auth_menu` VALUES (996012789342433537, '工作台', '', b'0', '/dashboard', '/dashboard/index', b'1', 0, 'el-icon-eleme', '', 981194468570960001, 0, 0, 1, '2022-07-11 11:19:14', 1, '2022-08-30 09:39:52');
INSERT INTO `itcast_auth_menu` VALUES (996013586302137537, '基础数据管理', '', b'0', '/transit', '/transit/index', b'1', 1, 'el-icon-medal', '', 981194468570960001, 0, 0, 1, '2022-07-11 11:22:24', 1, '2022-08-29 15:41:29');
INSERT INTO `itcast_auth_menu` VALUES (996013688966116737, '车型管理', '', b'0', '/transit/car-models', '/transit/car-models/index', b'1', 0, '', '', 981194468570960001, 1013825825621851521, 0, 1, '2022-07-11 11:22:49', 1, '2022-08-30 09:58:54');
INSERT INTO `itcast_auth_menu` VALUES (996013733509625409, '车辆列表', '', b'0', '/transit/vehicle', '/transit/vehicle/index', b'1', 1, '', '', 981194468570960001, 1013825825621851521, 0, 1, '2022-07-11 11:22:59', 1, '2022-08-30 09:58:54');
INSERT INTO `itcast_auth_menu` VALUES (996013790027872001, '司机管理', '', b'0', '/transit/driver', '/transit/driver/index', b'1', 2, '', '', 981194468570960001, 1013826500665722913, 0, 1, '2022-07-11 11:23:13', 1, '2022-08-30 09:58:57');
INSERT INTO `itcast_auth_menu` VALUES (996013832419702721, '排班管理', '', b'0', '/transit/workArrange-manage', '/transit/workArrange-manage/index', b'1', 3, '', '', 981194468570960001, 1013826500665722913, 0, 1, '2022-07-11 11:23:23', 1, '2022-08-30 09:58:57');
INSERT INTO `itcast_auth_menu` VALUES (996013891701995649, '运费管理', '', b'0', '/transit/freight-manage', '/transit/freight-manage/index', b'1', 4, '', '', 981194468570960001, 996013586302137537, 0, 1, '2022-07-11 11:23:37', 1, '2022-08-29 15:41:29');
INSERT INTO `itcast_auth_menu` VALUES (996014006701423169, '营业部管理', '', b'0', '/branches', '/branches/index', b'1', 3, '', '', 981194468570960001, 0, 0, 1, '2022-07-11 11:24:04', 1, '2022-08-29 18:38:50');
INSERT INTO `itcast_auth_menu` VALUES (996014097885592353, '机构管理', '', b'0', '/branches/organization-manage', '/branches/organization-manage/index', b'1', 0, '', '', 981194468570960001, 996013586302137537, 0, 1, '2022-07-11 11:24:26', 1, '2022-08-29 15:41:29');
INSERT INTO `itcast_auth_menu` VALUES (996014173659888673, '机构作业范围', '', b'0', '/branches/institutions-jobs-area', '/branches/institutions-jobs-area/index', b'1', 0, '', '', 981194468570960001, 996013586302137537, 0, 1, '2022-07-11 11:24:44', 1, '2022-08-29 15:41:29');
INSERT INTO `itcast_auth_menu` VALUES (996014256233151713, '快递作业管理', '', b'0', '/branches/operational', '/branches/operational/index', b'0', 0, '', '', 981194468570960001, 996014596043080033, 0, 1, '2022-07-11 11:25:04', 1, '2022-09-06 09:46:20');
INSERT INTO `itcast_auth_menu` VALUES (996014324117962145, '快递员管理', '', b'0', '/branches/operational-range', '/branches/operational-range/index', b'1', 0, '', '', 981194468570960001, 1013826500665722913, 0, 1, '2022-07-11 11:25:20', 1, '2022-08-30 09:58:57');
INSERT INTO `itcast_auth_menu` VALUES (996014377347874401, '货品类型管理', '', b'0', '/branches/goods-type', '/branches/goods-type/index', b'1', 1, '', '', 981194468570960001, 996014006701423169, 0, 1, '2022-07-11 11:25:33', 1, '2022-08-29 18:38:50');
INSERT INTO `itcast_auth_menu` VALUES (996014431324372769, '业务管理', '', b'0', '/business', '/business/index', b'1', 4, 'el-icon-set-up', '', 981194468570960001, 0, 0, 1, '2022-07-11 11:25:46', 1, '2022-08-29 16:48:32');
INSERT INTO `itcast_auth_menu` VALUES (996014478124416993, '订单管理', '', b'0', '/business/order-manage', '/business/order-manage/index', b'1', 0, '', '', 981194468570960001, 996014431324372769, 0, 1, '2022-07-11 11:25:57', 1, '2022-08-29 16:48:31');
INSERT INTO `itcast_auth_menu` VALUES (996014533355012257, '运单管理', '', b'0', '/business/waybill', '/business/waybill/index', b'1', 1, '', '', 981194468570960001, 996014431324372769, 0, 1, '2022-07-11 11:26:10', 1, '2022-08-29 16:48:31');
INSERT INTO `itcast_auth_menu` VALUES (996014596043080033, '调度管理', '', b'0', '/transport', '/transport/index', b'1', 5, 'el-icon-service', '', 981194468570960001, 0, 0, 1, '2022-07-11 11:26:25', 1, '2022-08-29 17:08:49');
INSERT INTO `itcast_auth_menu` VALUES (996014640003580449, '运输任务管理', '', b'0', '/transport/transport-task', '/transport/transport-task/index', b'1', 0, '', '', 981194468570960001, 996014596043080033, 0, 1, '2022-07-11 11:26:35', 1, '2022-08-29 17:08:49');
INSERT INTO `itcast_auth_menu` VALUES (996014685012656865, '线路管理', '', b'0', '/transport/line-manage', '/transport/line-manage/index', b'1', 1, '', '', 981194468570960001, 996014596043080033, 0, 1, '2022-07-11 11:26:46', 1, '2022-08-29 17:08:49');
INSERT INTO `itcast_auth_menu` VALUES (996014742650782625, '异常管理', '', b'0', '/1', '/1/index', b'0', 2, '', '', 981194468570960001, 996014596043080033, 0, 1, '2022-07-11 11:27:00', 1, '2022-08-30 09:08:48');
INSERT INTO `itcast_auth_menu` VALUES (996014803833095265, '回车登记', '', b'0', '/transit/car-register', '/transit/car-register/index', b'1', 3, '', '', 981194468570960001, 1013825825621851521, 0, 1, '2022-07-11 11:27:15', 1, '2022-09-08 15:32:50');
INSERT INTO `itcast_auth_menu` VALUES (996014852663182625, '系统管理', '', b'0', '/1', '/1/index', b'0', 6, '', '', 981194468570960001, 0, 0, 1, '2022-07-11 11:27:26', 1, '2022-07-20 11:58:40');
INSERT INTO `itcast_auth_menu` VALUES (996014922599007713, '用户管理', '', b'0', '/1', '/1/index', b'0', 0, '', '', 981194468570960001, 996014852663182625, 0, 1, '2022-07-11 11:27:43', 1, '2022-07-20 11:58:40');
INSERT INTO `itcast_auth_menu` VALUES (996014969143199393, '操作日志', '', b'0', '/1', '/1/index', b'0', 2, '', '', 981194468570960001, 996014852663182625, 0, 1, '2022-07-11 11:27:54', 1, '2022-07-20 11:58:40');
INSERT INTO `itcast_auth_menu` VALUES (996015016501086049, '登录日志', '', b'0', '/1', '/1/index', b'0', 1, '', '', 981194468570960001, 996014852663182625, 0, 1, '2022-07-11 11:28:05', 1, '2022-07-20 11:58:40');
INSERT INTO `itcast_auth_menu` VALUES (1013825825621851521, '车辆管理', '', b'0', '/transit1', '/transit1/index', b'1', 2, 'el-icon-eleme', '', 981194468570960001, 0, 0, 1, '2022-08-29 15:01:53', 1, '2022-08-30 09:58:54');
INSERT INTO `itcast_auth_menu` VALUES (1013826500665722913, '员工管理', '', b'0', '/transit2', '/transit2/index', b'1', 3, 'el-icon-user', '', 981194468570960001, 0, 0, 1, '2022-08-29 15:04:34', 1, '2022-08-30 09:58:57');
INSERT INTO `itcast_auth_menu` VALUES (1016645172630893697, '取件作业管理', '', b'0', '/branches/pickUptask', '/branches/pickUptask/index', b'1', 3, '', '', 981194468570960001, 996014596043080033, 0, 1, '2022-09-06 09:44:58', 1, '2022-09-06 09:46:09');
INSERT INTO `itcast_auth_menu` VALUES (1016645380668372641, '派件作业管理', '', b'0', '/branches/dispatchTask', '/branches/dispatchTask/index', b'1', 4, '', '', 981194468570960001, 996014596043080033, 0, 1, '2022-09-06 09:45:47', 1, '2022-09-07 14:07:02');

-- ----------------------------
-- Table structure for itcast_auth_resource
-- ----------------------------
DROP TABLE IF EXISTS `itcast_auth_resource`;
CREATE TABLE `itcast_auth_resource`  (
  `id` bigint NOT NULL COMMENT 'ID',
  `code` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '资源编码\n规则：\n链接：\n数据列：\n按钮：',
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '接口名称',
  `menu_id` bigint NULL DEFAULT NULL COMMENT '菜单ID\n#c_auth_menu',
  `method` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `describe_` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '接口描述',
  `application_id` bigint NULL DEFAULT NULL COMMENT '应用id',
  `create_user` bigint NULL DEFAULT NULL COMMENT '创建人id',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_user` bigint NULL DEFAULT NULL COMMENT '更新人id',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `UN_CODE`(`code` ASC) USING BTREE COMMENT '编码唯一'
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '资源' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of itcast_auth_resource
-- ----------------------------
INSERT INTO `itcast_auth_resource` VALUES (643444685339100193, 'org:add', '添加', 603982542332235201, 'POST', '/org', '', 1, 3, '2019-11-12 13:39:28', 3, '2019-11-12 13:39:50');
INSERT INTO `itcast_auth_resource` VALUES (643444685339100194, 'role:config', '配置', 603981723864141121, 'POST', '/role/authority', '', 1, 3, '2019-11-12 13:39:28', 3, '2020-03-04 19:57:51');
INSERT INTO `itcast_auth_resource` VALUES (643444685339100195, 'resource:add', '添加资源', 603976297063910529, 'POST', '/resource', '', 1, 3, '2019-11-12 13:39:28', 1, '2021-03-20 01:47:26');
INSERT INTO `itcast_auth_resource` VALUES (643444685339100196, 'resource:update', '修改资源', 603976297063910529, 'PUT', '/resource', '', 1, 3, '2019-11-12 13:39:28', 1, '2021-03-20 01:47:34');
INSERT INTO `itcast_auth_resource` VALUES (643444685339100197, 'resource:delete', '删除资源', 603976297063910529, 'DELETE', '/resource', '', 1, 3, '2019-11-12 13:39:28', 1, '2021-03-20 01:47:40');
INSERT INTO `itcast_auth_resource` VALUES (643444819758154945, 'org:update', '修改', 603982542332235201, 'PUT', '/org', '', 1, 3, '2019-11-12 13:40:00', 3, '2019-11-12 13:40:00');
INSERT INTO `itcast_auth_resource` VALUES (643444858974897441, 'org:delete', '删除', 603982542332235201, 'DELETE', '/org', '', 1, 3, '2019-11-12 13:40:09', 3, '2019-11-12 13:40:09');
INSERT INTO `itcast_auth_resource` VALUES (643444897201784193, 'org:tree', '组织树', 603982542332235201, 'GET', '/org/tree', '', 1, 3, '2019-11-12 13:40:18', 3, '2020-03-04 19:53:41');
INSERT INTO `itcast_auth_resource` VALUES (643445116756821697, 'station:add', '添加', 603982713849908801, 'POST', '/station', '', 1, 3, '2019-11-12 13:41:11', 3, '2019-11-12 13:41:11');
INSERT INTO `itcast_auth_resource` VALUES (643445162915137313, 'station:update', '修改', 603982713849908801, 'PUT', '/station', '', 1, 3, '2019-11-12 13:41:22', 3, '2019-11-12 13:41:22');
INSERT INTO `itcast_auth_resource` VALUES (643445197954353025, 'station:delete', '删除', 603982713849908801, 'DELETE', '/station', '', 1, 3, '2019-11-12 13:41:30', 3, '2019-11-12 13:41:30');
INSERT INTO `itcast_auth_resource` VALUES (643445229575210977, 'station:page', '分页', 603982713849908801, 'GET', '/station/page', '', 1, 3, '2019-11-12 13:41:38', 3, '2020-04-10 09:21:06');
INSERT INTO `itcast_auth_resource` VALUES (643445352703199521, 'user:add', '添加', 101, 'POST', '/user', '', 1, 3, '2019-11-12 13:42:07', 3, '2020-03-10 21:34:38');
INSERT INTO `itcast_auth_resource` VALUES (643445412774021505, 'user:update', '修改', 101, 'PUT', '/user/*', '', 1, 3, '2019-11-12 13:42:21', 1, '2021-11-25 14:53:11');
INSERT INTO `itcast_auth_resource` VALUES (643445448081672673, 'user:delete', '删除', 101, 'DELETE', '/user', '', 1, 3, '2019-11-12 13:42:30', 3, '2019-11-12 13:42:30');
INSERT INTO `itcast_auth_resource` VALUES (643445477274028609, 'user:page', '分页', 101, 'GET', '/user/page', '', 1, 3, '2019-11-12 13:42:37', 1, '2021-08-13 17:40:15');
INSERT INTO `itcast_auth_resource` VALUES (643445514607528609, 'user:import', '导入', 101, 'POST', '/user/importExcel', '', 1, 3, '2019-11-12 13:42:46', 822139309904628833, '2021-03-19 16:40:48');
INSERT INTO `itcast_auth_resource` VALUES (643445641149680705, 'menu:add', '添加菜单', 603976297063910529, 'POST', '/menu', '', 1, 3, '2019-11-12 13:43:16', 1, '2021-03-20 01:47:50');
INSERT INTO `itcast_auth_resource` VALUES (643445674330819745, 'menu:update', '修改菜单', 603976297063910529, 'PUT', '/menu', '', 1, 3, '2019-11-12 13:43:24', 1, '2021-03-20 01:47:54');
INSERT INTO `itcast_auth_resource` VALUES (643445704177487105, 'menu:delete', '删除菜单', 603976297063910529, 'DELETE', '/menu', '', 1, 3, '2019-11-12 13:43:31', 1, '2021-03-20 01:48:00');
INSERT INTO `itcast_auth_resource` VALUES (643448338154263521, 'role:add', '添加', 603981723864141121, 'POST', '/role', '', 1, 3, '2019-11-12 13:53:59', 3, '2019-11-12 13:53:59');
INSERT INTO `itcast_auth_resource` VALUES (643448369779315777, 'role:update', '修改', 603981723864141121, 'PUT', '/role', '', 1, 3, '2019-11-12 13:54:06', 3, '2019-11-12 13:54:06');
INSERT INTO `itcast_auth_resource` VALUES (643448507767723169, 'role:delete', '删除', 603981723864141121, 'DELETE', '/role', '', 1, 3, '2019-11-12 13:54:39', 3, '2019-11-12 13:54:39');
INSERT INTO `itcast_auth_resource` VALUES (643448611161511169, 'role:page', '分页', 603981723864141121, 'GET', '/role/page', '', 1, 3, '2019-11-12 13:55:04', 3, '2020-03-04 19:55:44');
INSERT INTO `itcast_auth_resource` VALUES (643448826945869409, 'role:auth', '授权', 603981723864141121, 'POST', '/role/user', '', 1, 3, '2019-11-12 13:55:55', 3, '2020-03-04 19:57:57');
INSERT INTO `itcast_auth_resource` VALUES (643450770317909249, 'optLog:view', '查看', 605078672772170209, 'GET', '/optLog/page', '', 1, 3, '2019-11-12 14:03:39', 3, '2020-03-10 21:45:24');
INSERT INTO `itcast_auth_resource` VALUES (643450853134441825, 'optLog:export', '导出', 605078672772170209, 'GET', '/optLog', '', 1, 3, '2019-11-12 14:03:58', 3, '2019-11-12 14:03:58');
INSERT INTO `itcast_auth_resource` VALUES (645288214990422241, 'optLog:delete', '删除', 605078672772170209, 'DELETE', '/optLog', '', 1, 3, '2019-11-17 15:45:00', 3, '2019-11-17 15:45:00');
INSERT INTO `itcast_auth_resource` VALUES (645288283693121889, 'loginLog:delete', '删除', 645215230518909025, 'DELETE', '/loginLog', '', 1, 3, '2019-11-17 15:45:16', 3, '2019-11-17 15:45:16');
INSERT INTO `itcast_auth_resource` VALUES (645288375300915649, 'loginLog:export', '导出', 645215230518909025, 'GET', '/loginLog', '', 1, 3, '2019-11-17 15:45:38', 3, '2019-11-17 15:45:38');
INSERT INTO `itcast_auth_resource` VALUES (684536767625301441, 'rule:config-get', '配置-查看', 603981723864141121, 'GET', '/role/authority/*', '', 1, 3, '2020-03-04 23:04:44', 3, '2020-03-04 23:26:26');
INSERT INTO `itcast_auth_resource` VALUES (684539815017848257, 'resource:page', '资源分页', 603976297063910529, 'GET', '/resource/page', '', 1, 3, '2020-03-04 23:16:50', 1, '2021-03-20 01:48:11');
INSERT INTO `itcast_auth_resource` VALUES (686681252069121761, 'role:user-list', '查看用户', 603981723864141121, 'GET', '/role/user/*', '', 1, 3, '2020-03-10 21:06:09', 3, '2020-03-10 21:06:09');
INSERT INTO `itcast_auth_resource` VALUES (686690530444191361, 'loginLog:page', '分页查询', 645215230518909025, 'GET', '/loginLog/page', '', 1, 3, '2020-03-10 21:43:01', 3, '2020-03-10 21:47:09');
INSERT INTO `itcast_auth_resource` VALUES (697738050637137985, 'station:list', '查询', 603982713849908801, 'GET', '/station/list', '', 1, 3, '2020-04-10 09:21:55', 3, '2020-04-10 09:21:55');
INSERT INTO `itcast_auth_resource` VALUES (819979689903793377, 'role:get', '查看角色', 603981723864141121, 'GET', '/role/*', '', 1, 3, '2021-03-13 17:06:33', 3, '2021-03-13 17:06:33');
INSERT INTO `itcast_auth_resource` VALUES (819980292310707361, 'menu:resource-tree', '查看菜单资源树', 603981723864141121, 'GET', '/menu/resource/tree', '', 1, 3, '2021-03-13 17:08:56', 3, '2021-03-13 17:08:56');
INSERT INTO `itcast_auth_resource` VALUES (819980764757114209, 'menu:get', '查看菜单', 603976297063910529, 'GET', '/menu/*', '', 1, 3, '2021-03-13 17:10:49', 1, '2021-03-20 01:48:19');
INSERT INTO `itcast_auth_resource` VALUES (819981352018401697, 'org:get', '查看组织', 603982542332235201, 'GET', '/org/*', '', 1, 3, '2021-03-13 17:13:09', 3, '2021-03-13 17:13:09');
INSERT INTO `itcast_auth_resource` VALUES (819981559128939745, 'menu:enable', '禁用菜单', 603976297063910529, 'PUT', '/menu/enable', '', 1, 3, '2021-03-13 17:13:58', 1, '2021-03-20 01:48:28');
INSERT INTO `itcast_auth_resource` VALUES (819984731746600865, 'org:status', '组织状态变更', 603982542332235201, 'PUT', '/org/status', '', 1, 3, '2021-03-13 17:26:35', 3, '2021-03-13 17:26:35');
INSERT INTO `itcast_auth_resource` VALUES (819985775964724545, 'org:move', '拖动组织', 603982542332235201, 'PUT', '/org/move', '', 1, 3, '2021-03-13 17:30:44', 3, '2021-03-13 17:30:44');
INSERT INTO `itcast_auth_resource` VALUES (820003240325155361, 'menu:move', '移动菜单', 603976297063910529, 'PUT', '/menu/move', '', 1, 819970379316561441, '2021-03-13 18:40:08', 819970379316561441, '2021-03-13 18:40:08');
INSERT INTO `itcast_auth_resource` VALUES (821040097440002593, 'user:get', '查询用户', 101, 'GET', '/user/*', '', 1, 821033290931822305, '2021-03-16 15:20:14', 1, '2021-08-13 17:40:30');
INSERT INTO `itcast_auth_resource` VALUES (821043867263674209, 'resource:get', '查看资源', 603976297063910529, 'GET', '/resource/*', '', 1, 821033290931822305, '2021-03-16 15:35:12', 1, '2021-03-20 01:48:41');
INSERT INTO `itcast_auth_resource` VALUES (857648193905653729, 'application:list', '查询应用列表', 603981723864141121, 'GET', '/application/list', '', 1, 1, '2021-06-24 15:47:44', 1, '2021-06-24 15:48:05');
INSERT INTO `itcast_auth_resource` VALUES (860103477676743073, 'user:listall', '查询全部用户', 101, 'GET', '/user', '', 1, 1, '2021-07-01 10:24:09', 1, '2021-07-01 10:24:09');
INSERT INTO `itcast_auth_resource` VALUES (874599773141730049, 'user:update-role', '分配角色', 101, 'PUT', '/user/role', '', 1, 1, '2021-08-10 10:27:15', 1, '2021-08-10 10:27:26');
INSERT INTO `itcast_auth_resource` VALUES (876848743419269377, 'application:page', '分页', 829717676565049825, 'GET', '/application/page', '', 1, 1, '2021-08-16 15:23:52', 1, '2021-08-16 15:23:52');
INSERT INTO `itcast_auth_resource` VALUES (876848904275022241, 'application:add', '添加', 829717676565049825, 'POST', '/application', '', 1, 1, '2021-08-16 15:24:30', 1, '2021-08-16 15:24:30');
INSERT INTO `itcast_auth_resource` VALUES (876849034311029281, 'application:update', '修改', 829717676565049825, 'PUT', '/application', '', 1, 1, '2021-08-16 15:25:01', 1, '2021-08-16 15:25:01');
INSERT INTO `itcast_auth_resource` VALUES (876849208202678913, 'application:delete', '删除', 829717676565049825, 'DELETE', '/application', '', 1, 1, '2021-08-16 15:25:43', 1, '2021-08-16 15:25:43');
INSERT INTO `itcast_auth_resource` VALUES (906124052698017729, 'user:orgtree', '查看组织树', 101, 'GET', '/org/tree', '', 1, 1, '2021-11-05 10:13:29', 1, '2021-11-05 10:13:29');
INSERT INTO `itcast_auth_resource` VALUES (906124162924326945, 'user:stationlist', '查看岗位列表', 101, 'GET', '/station/list', '', 1, 1, '2021-11-05 10:13:56', 1, '2021-11-05 10:30:39');
INSERT INTO `itcast_auth_resource` VALUES (913442483030066881, 'user:password', '修改密码', 101, 'PUT', '/user/password', '', 1, 1, '2021-11-25 14:54:19', 1, '2021-11-25 14:54:19');
INSERT INTO `itcast_auth_resource` VALUES (986227394014626977, '1', '车辆类型', NULL, 'get', '1', '', 981194468570960001, 1, '2022-06-14 11:15:34', 1, '2022-06-14 11:15:34');
INSERT INTO `itcast_auth_resource` VALUES (996013208424706753, '01', 'get', 996012789342433537, 'get', '/manager', '', 981194468570960001, 1, '2022-07-11 11:20:54', 1, '2022-07-11 11:20:54');

-- ----------------------------
-- Table structure for itcast_auth_role
-- ----------------------------
DROP TABLE IF EXISTS `itcast_auth_role`;
CREATE TABLE `itcast_auth_role`  (
  `id` bigint NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '角色名称',
  `code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '角色编码',
  `describe_` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '功能描述',
  `status` bit(1) NULL DEFAULT b'1' COMMENT '状态',
  `readonly` bit(1) NULL DEFAULT b'0' COMMENT '是否内置角色',
  `ds_type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'SELF' COMMENT '数据权限类型\n#DataScopeType{ALL:1,全部;THIS_LEVEL:2,本级;THIS_LEVEL_CHILDREN:3,本级以及子级;CUSTOMIZE:4,自定义;SELF:5,个人;}',
  `repel` bigint NULL DEFAULT NULL COMMENT '互斥角色',
  `application_id` bigint NULL DEFAULT NULL COMMENT '应用id',
  `create_user` bigint NULL DEFAULT 0 COMMENT '创建人id',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_user` bigint NULL DEFAULT 0 COMMENT '更新人id',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `UN_CODE`(`code` ASC, `application_id` ASC) USING BTREE,
  UNIQUE INDEX `PAR_NAME`(`name` ASC, `application_id` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '角色' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of itcast_auth_role
-- ----------------------------
INSERT INTO `itcast_auth_role` VALUES (986227712144197857, '后台管理员', '1655176610005', '', b'1', b'0', 'CUSTOMIZE', NULL, 981194468570960001, 1, '2022-06-14 11:16:50', 1, '2022-09-16 16:50:00');
INSERT INTO `itcast_auth_role` VALUES (989278284569131905, '营业部负责人', '1655903923152', '', b'1', b'0', 'THIS_LEVEL_CHILDREN', NULL, 981194468570960001, 1, '2022-06-22 21:18:43', 1, '2022-07-11 13:30:19');
INSERT INTO `itcast_auth_role` VALUES (989559028277315009, '司机', '1655970857665', '', b'1', b'0', 'ALL', NULL, 981194468570960001, 1, '2022-06-23 15:54:18', 1, '2022-06-23 15:54:18');
INSERT INTO `itcast_auth_role` VALUES (989559057641637825, '快递员', '1655970864670', '', b'1', b'0', 'ALL', NULL, 981194468570960001, 1, '2022-06-23 15:54:25', 1, '2022-06-23 15:54:25');
INSERT INTO `itcast_auth_role` VALUES (996045142395786081, '运营人员', '1657517267777', '', b'1', b'0', 'ALL', NULL, 981194468570960001, 1, '2022-07-11 13:27:48', 1, '2022-07-11 13:32:16');
INSERT INTO `itcast_auth_role` VALUES (996045927523359809, '调度员', '1657517454970', '', b'1', b'0', 'ALL', NULL, 981194468570960001, 1, '2022-07-11 13:30:55', 1, '2022-07-11 13:30:55');
INSERT INTO `itcast_auth_role` VALUES (996073836908694177, '客服', '1657524109022', '', b'1', b'0', 'ALL', NULL, 981194468570960001, 1, '2022-07-11 15:21:49', 1, '2022-07-11 15:21:49');
INSERT INTO `itcast_auth_role` VALUES (996074071437397857, '库管员', '1657524165002', '', b'0', b'0', 'ALL', NULL, 981194468570960001, 1, '2022-07-11 15:22:45', 1, '2022-07-11 15:22:49');
INSERT INTO `itcast_auth_role` VALUES (996074230309245665, '分拣中心管理员', '1657524202880', '', b'0', b'0', 'ALL', NULL, 981194468570960001, 1, '2022-07-11 15:23:23', 1, '2022-07-11 16:43:57');

-- ----------------------------
-- Table structure for itcast_auth_role_application
-- ----------------------------
DROP TABLE IF EXISTS `itcast_auth_role_application`;
CREATE TABLE `itcast_auth_role_application`  (
  `id` bigint NOT NULL COMMENT 'ID',
  `role_id` bigint NULL DEFAULT NULL COMMENT '角色ID',
  `application_id` bigint NULL DEFAULT NULL COMMENT '应用ID',
  `create_time` datetime NULL DEFAULT NULL,
  `create_user` bigint NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '角色应用关系' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of itcast_auth_role_application
-- ----------------------------

-- ----------------------------
-- Table structure for itcast_auth_role_authority
-- ----------------------------
DROP TABLE IF EXISTS `itcast_auth_role_authority`;
CREATE TABLE `itcast_auth_role_authority`  (
  `id` bigint NOT NULL COMMENT '主键',
  `authority_id` bigint NOT NULL COMMENT '资源id\n#c_auth_resource\n#c_auth_menu',
  `authority_type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT 'MENU' COMMENT '权限类型\n#AuthorizeType{MENU:菜单;RESOURCE:资源;}',
  `role_id` bigint NOT NULL COMMENT '角色id\n#c_auth_role',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `create_user` bigint NULL DEFAULT 0 COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IDX_KEY`(`role_id` ASC, `authority_type` ASC, `authority_id` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '角色的资源' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of itcast_auth_role_authority
-- ----------------------------
INSERT INTO `itcast_auth_role_authority` VALUES (996012379311467553, 991639496929840865, 'RESOURCE', 989559057641637825, '2022-07-11 11:17:36', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996094418903688641, 996014533355012257, 'MENU', 996045142395786081, '2022-07-11 16:43:36', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996094418907882977, 996014478124416993, 'MENU', 996045142395786081, '2022-07-11 16:43:36', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996094418907883009, 996012789342433537, 'MENU', 996045142395786081, '2022-07-11 16:43:36', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996094418907883041, 996013333960225793, 'MENU', 996045142395786081, '2022-07-11 16:43:36', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996094418907883073, 996014431324372769, 'MENU', 996045142395786081, '2022-07-11 16:43:36', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996094433457924001, 996014533355012257, 'MENU', 996073836908694177, '2022-07-11 16:43:40', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996094433462118337, 996014478124416993, 'MENU', 996073836908694177, '2022-07-11 16:43:40', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996094433462118369, 996012789342433537, 'MENU', 996073836908694177, '2022-07-11 16:43:40', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996094433462118401, 996014431324372769, 'MENU', 996073836908694177, '2022-07-11 16:43:40', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095179888848737, 996014324117962145, 'MENU', 989278284569131905, '2022-07-11 16:46:38', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095179893043073, 996014256233151713, 'MENU', 989278284569131905, '2022-07-11 16:46:38', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095179893043105, 996014006701423169, 'MENU', 989278284569131905, '2022-07-11 16:46:38', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095179893043137, 996014097885592353, 'MENU', 989278284569131905, '2022-07-11 16:46:38', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095179893043169, 996012789342433537, 'MENU', 989278284569131905, '2022-07-11 16:46:38', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095179893043201, 996014173659888673, 'MENU', 989278284569131905, '2022-07-11 16:46:38', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095179893043233, 996014377347874401, 'MENU', 989278284569131905, '2022-07-11 16:46:38', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095234590962049, 996014533355012257, 'MENU', 996074071437397857, '2022-07-11 16:46:51', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095234595156385, 996014478124416993, 'MENU', 996074071437397857, '2022-07-11 16:46:51', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095234595156417, 996014431324372769, 'MENU', 996074071437397857, '2022-07-11 16:46:51', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095332708315937, 996013790027872001, 'MENU', 996074230309245665, '2022-07-11 16:47:14', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095332712510273, 996014533355012257, 'MENU', 996074230309245665, '2022-07-11 16:47:14', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095332712510305, 996013733509625409, 'MENU', 996074230309245665, '2022-07-11 16:47:14', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095332712510337, 996013586302137537, 'MENU', 996074230309245665, '2022-07-11 16:47:14', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095332712510369, 996014478124416993, 'MENU', 996074230309245665, '2022-07-11 16:47:14', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095332712510401, 996013891701995649, 'MENU', 996074230309245665, '2022-07-11 16:47:14', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095332716704737, 996012789342433537, 'MENU', 996074230309245665, '2022-07-11 16:47:14', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095332716704769, 996013333960225793, 'MENU', 996074230309245665, '2022-07-11 16:47:14', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095332716704801, 996014431324372769, 'MENU', 996074230309245665, '2022-07-11 16:47:14', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095332716704833, 996013832419702721, 'MENU', 996074230309245665, '2022-07-11 16:47:14', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (996095332716704865, 996013688966116737, 'MENU', 996074230309245665, '2022-07-11 16:47:14', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368476426817, 686681252069121761, 'RESOURCE', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368480621153, 876848743419269377, 'RESOURCE', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368480621185, 643444685339100193, 'RESOURCE', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368480621217, 876848904275022241, 'RESOURCE', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368480621249, 821040097440002593, 'RESOURCE', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368484815585, 857648193905653729, 'RESOURCE', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368484815617, 643445477274028609, 'RESOURCE', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368484815649, 684536767625301441, 'RESOURCE', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368484815681, 643445352703199521, 'RESOURCE', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368484815713, 645215230518909025, 'MENU', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368489010049, 834002593268115937, 'MENU', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368489010081, 829717676565049825, 'MENU', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368489010113, 603982713849908801, 'MENU', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368489010145, 101, 'MENU', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368489010177, 104, 'MENU', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368489010209, 603982542332235201, 'MENU', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368489010241, 605078672772170209, 'MENU', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368489010273, 603976297063910529, 'MENU', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1015270368489010305, 603981723864141121, 'MENU', 992434343932621473, '2022-09-02 14:41:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882241283073, 996014533355012257, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882245477409, 996014256233151713, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882245477441, 996013586302137537, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882245477473, 996013891701995649, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882245477505, 996014852663182625, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882249671841, 996012789342433537, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882249671873, 996014596043080033, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882249671905, 996013790027872001, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882249671937, 996014742650782625, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882249671969, 996015016501086049, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882249672001, 996014478124416993, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882249672033, 996014803833095265, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882253866369, 996013832419702721, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882253866401, 996013733509625409, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882253866433, 996014969143199393, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882253866465, 996014685012656865, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882253866497, 1013825825621851521, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882253866529, 1013826500665722913, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882253866561, 996014431324372769, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882253866593, 1016645380668372641, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882253866625, 996014173659888673, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882253866657, 996014324117962145, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882253866689, 996014097885592353, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882253866721, 1016645172630893697, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882253866753, 996014922599007713, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882253866785, 996014640003580449, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1017456882258061121, 996013688966116737, 'MENU', 986227712144197857, '2022-09-08 15:30:24', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1027527635309523681, 996014256233151713, 'MENU', 996045927523359809, '2022-10-06 10:27:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1027527635313718017, 996013586302137537, 'MENU', 996045927523359809, '2022-10-06 10:27:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1027527635313718049, 996014685012656865, 'MENU', 996045927523359809, '2022-10-06 10:27:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1027527635313718081, 1013825825621851521, 'MENU', 996045927523359809, '2022-10-06 10:27:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1027527635313718113, 1013826500665722913, 'MENU', 996045927523359809, '2022-10-06 10:27:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1027527635317912449, 996014596043080033, 'MENU', 996045927523359809, '2022-10-06 10:27:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1027527635317912481, 996014173659888673, 'MENU', 996045927523359809, '2022-10-06 10:27:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1027527635317912513, 996013790027872001, 'MENU', 996045927523359809, '2022-10-06 10:27:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1027527635317912545, 996014742650782625, 'MENU', 996045927523359809, '2022-10-06 10:27:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1027527635317912577, 996014324117962145, 'MENU', 996045927523359809, '2022-10-06 10:27:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1027527635317912609, 996014097885592353, 'MENU', 996045927523359809, '2022-10-06 10:27:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1027527635317912641, 996014640003580449, 'MENU', 996045927523359809, '2022-10-06 10:27:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1027527635317912673, 996014803833095265, 'MENU', 996045927523359809, '2022-10-06 10:27:59', 1);
INSERT INTO `itcast_auth_role_authority` VALUES (1027527635317912705, 996013832419702721, 'MENU', 996045927523359809, '2022-10-06 10:27:59', 1);

-- ----------------------------
-- Table structure for itcast_auth_role_org
-- ----------------------------
DROP TABLE IF EXISTS `itcast_auth_role_org`;
CREATE TABLE `itcast_auth_role_org`  (
  `id` bigint NOT NULL COMMENT 'ID',
  `role_id` bigint NULL DEFAULT NULL COMMENT '角色ID\n#c_auth_role',
  `org_id` bigint NULL DEFAULT NULL COMMENT '部门ID\n#c_core_org',
  `create_time` datetime NULL DEFAULT NULL,
  `create_user` bigint NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '角色组织关系' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of itcast_auth_role_org
-- ----------------------------

-- ----------------------------
-- Table structure for itcast_auth_user
-- ----------------------------
DROP TABLE IF EXISTS `itcast_auth_user`;
CREATE TABLE `itcast_auth_user`  (
  `id` bigint NOT NULL COMMENT 'ID',
  `account` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '账号',
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL COMMENT '姓名',
  `org_id` bigint NULL DEFAULT NULL COMMENT '组织ID\n#c_core_org',
  `station_id` bigint NULL DEFAULT NULL COMMENT '岗位ID\n#c_core_station',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '邮箱',
  `mobile` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '手机',
  `sex` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'N' COMMENT '性别\n#Sex{W:女;M:男;N:未知}',
  `status` bit(1) NULL DEFAULT b'0' COMMENT '启用状态 1启用 0禁用',
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '头像',
  `work_describe` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '工作描述\r\n比如：  市长、管理员、局长等等   用于登陆展示',
  `password_error_last_time` datetime NULL DEFAULT NULL COMMENT '最后一次输错密码时间',
  `password_error_num` int NULL DEFAULT 0 COMMENT '密码错误次数',
  `password_expire_time` datetime NULL DEFAULT NULL COMMENT '密码过期时间',
  `password` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '密码',
  `last_login_time` datetime NULL DEFAULT NULL COMMENT '最后登录时间',
  `superior` bigint NULL DEFAULT NULL COMMENT '上级领导',
  `administrator` bit(1) NOT NULL DEFAULT b'0' COMMENT '超级管理员',
  `create_user` bigint NULL DEFAULT 0 COMMENT '创建人id',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_user` bigint NULL DEFAULT 0 COMMENT '更新人id',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `UN_ACCOUNT`(`account` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '用户' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of itcast_auth_user
-- ----------------------------
INSERT INTO `itcast_auth_user` VALUES (1, 'admin', '平台管理员', 874227615173449825, 857940157460957537, '', '13756644565', 'M', b'1', 'http://oss-file-services.oss-cn-zhangjiakou.aliyuncs.com/pd_files/2021/04/ffdc9d9b-287f-4c5c-beb5-8487132898d3.jpg', '超级管理员', '2022-10-18 10:17:42', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', '2022-10-18 10:17:42', -1, b'1', 1, '2019-09-02 19:32:02', 1, '2021-12-02 09:16:44');
INSERT INTO `itcast_auth_user` VALUES (1024705709255773345, 'shenlingadmin', '神领管理员', 1024704844486756641, 1024705489436494721, NULL, '18500557669', 'M', b'1', '', '', '2022-10-19 08:01:32', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, 1, b'0', 1, '2022-09-28 15:34:39', 1, '2022-09-28 15:34:39');
INSERT INTO `itcast_auth_user` VALUES (1024738476802799553, 'xbsj001', '周一', 1024704844486756641, 1024707535891944769, NULL, '13571250987', 'M', b'1', '', '', '2022-09-29 15:35:41', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-28 17:44:52', 1, '2022-09-28 17:44:52');
INSERT INTO `itcast_auth_user` VALUES (1024738594893428865, 'xbsj002', '周二', 1024704844486756641, 1024707535891944769, NULL, '18500224566', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-28 17:45:20', 1, '2022-09-28 17:45:20');
INSERT INTO `itcast_auth_user` VALUES (1024741978908228513, 'xnsj001', '吴用', 1024706655985685345, 1024707535891944769, NULL, '18500766555', 'M', b'1', '', '', '2022-09-29 16:28:50', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-28 17:58:47', 1, '2022-09-28 17:58:47');
INSERT INTO `itcast_auth_user` VALUES (1024742117286706369, 'xnsj002', '吴西', 1024706655985685345, 1024707535891944769, NULL, '18346766666', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-28 17:59:20', 1, '2022-09-28 17:59:20');
INSERT INTO `itcast_auth_user` VALUES (1024742265953811937, 'cdsj001', '成功', 1024706903290237921, 1024707535891944769, NULL, '18950867777', 'M', b'1', '', '', '2022-09-29 17:33:40', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-28 17:59:55', 1, '2022-09-28 17:59:55');
INSERT INTO `itcast_auth_user` VALUES (1024742403489234657, 'cdsj002', '成仁', 1024706903290237921, 1024707535891944769, NULL, '18394867666', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-28 18:00:28', 1, '2022-09-28 18:00:28');
INSERT INTO `itcast_auth_user` VALUES (1024976390379916929, 'xasj001', '西王', 1024772115791985729, 1024707535891944769, NULL, '18355544444', 'M', b'1', '', '', '2022-09-29 15:39:45', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 09:30:15', 1, '2022-09-29 09:30:15');
INSERT INTO `itcast_auth_user` VALUES (1024976605161836353, 'xasj002', '西米', 1024772115791985729, 1024707535891944769, NULL, '17655555555', 'M', b'1', '', '', '2022-09-29 10:51:59', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 09:31:06', 1, '2022-09-29 09:31:06');
INSERT INTO `itcast_auth_user` VALUES (1024976781221941281, 'blkdy001', '贝林', 1024772301733870785, 1024707516816250081, NULL, '13434343434', 'M', b'1', '', '', '2022-10-17 15:17:04', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 09:31:48', 1, '2022-09-29 09:31:48');
INSERT INTO `itcast_auth_user` VALUES (1024976941658263777, 'blkdy002', '贝小贝', 1024772301733870785, 1024707516816250081, NULL, '13433434544', 'W', b'1', '', '', '2022-10-11 13:15:47', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 09:32:26', 1, '2022-09-29 09:32:26');
INSERT INTO `itcast_auth_user` VALUES (1024977078208025057, 'casj001', '长小名', 1024772425923018049, 1024707516816250081, NULL, '18364636473', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 09:32:59', 1, '2022-09-29 09:32:59');
INSERT INTO `itcast_auth_user` VALUES (1024977221418341025, 'casj002', '长城', 1024772425923018049, 1024707516816250081, NULL, '13445657565', 'W', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 09:33:33', 1, '2022-09-29 09:33:33');
INSERT INTO `itcast_auth_user` VALUES (1024977388880122881, 'jnkdy001', '金元宝', 1024771466287232801, 1024707516816250081, NULL, '18374673467', 'M', b'1', '', '', '2022-10-13 14:45:44', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 09:34:13', 1, '2022-09-29 09:34:13');
INSERT INTO `itcast_auth_user` VALUES (1024977522992993473, 'jnkdy002', '金开', 1024771466287232801, 1024707516816250081, NULL, '18374734736', 'M', b'1', '', '', '2022-10-06 14:53:14', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 09:34:45', 1, '2022-09-29 09:34:45');
INSERT INTO `itcast_auth_user` VALUES (1024977621806601633, 'qykdy001', '青青', 1024771753995515873, 1024707516816250081, NULL, '18273827382', 'W', b'1', '', '', '2022-10-18 15:06:13', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 09:35:08', 1, '2022-09-29 09:35:08');
INSERT INTO `itcast_auth_user` VALUES (1024977719693268993, 'qykdy002', '青风', 1024771753995515873, 1024707516816250081, NULL, '18273872382', 'M', b'1', '', '', '2022-10-18 15:02:37', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 09:35:32', 1, '2022-09-29 09:35:32');
INSERT INTO `itcast_auth_user` VALUES (1024984140988150081, 'hdsj001', '华亮', 1024980958136362977, 1024707535891944769, NULL, '18837473473', 'M', b'1', '', '', '2022-10-18 10:18:57', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:01:03', 1, '2022-09-29 10:01:03');
INSERT INTO `itcast_auth_user` VALUES (1024984230121304705, 'hdsj002', '华明', 1024980958136362977, 1024707535891944769, NULL, '13454545454', 'M', b'1', '', '', '2022-10-18 15:21:23', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:01:24', 1, '2022-09-29 10:01:24');
INSERT INTO `itcast_auth_user` VALUES (1024984365991588705, 'shsj001', '海明月', 1024980990084376673, 1024707535891944769, NULL, '18566666667', 'M', b'1', '', '', '2022-10-18 14:10:48', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:01:56', 1, '2022-09-29 10:01:56');
INSERT INTO `itcast_auth_user` VALUES (1024984516357387297, 'shsj002', '海阔', 1024980990084376673, 1024707535891944769, NULL, '18734736473', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:02:32', 1, '2022-09-29 10:02:32');
INSERT INTO `itcast_auth_user` VALUES (1024984720745821569, 'hkkdy001', '周生生', 1024981295454874273, 1024707516816250081, NULL, '18776676767', 'W', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:03:21', 1, '2022-09-29 10:04:31');
INSERT INTO `itcast_auth_user` VALUES (1024984891772761697, 'hkkdy002', '周生辰', 1024981295454874273, 1024707516816250081, NULL, '13434343434', 'M', b'1', '', '', '2022-10-10 14:22:17', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:04:02', 1, '2022-09-29 10:04:02');
INSERT INTO `itcast_auth_user` VALUES (1024985344870841121, 'pdkdy001', '刘徽', 1024981239465110017, 1024707516816250081, NULL, '18737373647', 'M', b'1', '', '', '2022-10-10 10:25:01', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:05:50', 1, '2022-09-29 10:05:50');
INSERT INTO `itcast_auth_user` VALUES (1024985481462545409, 'pdkdy002', '萧晏', 1024981239465110017, 1024707516816250081, NULL, '18737473647', 'W', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:06:22', 1, '2022-09-29 10:06:22');
INSERT INTO `itcast_auth_user` VALUES (1024985621531327777, 'hbsj001', '平秦王', 1024980634071852417, 1024707535891944769, NULL, '18723736473', 'M', b'1', '', '', '2022-10-06 14:37:27', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:06:56', 1, '2022-09-29 10:06:56');
INSERT INTO `itcast_auth_user` VALUES (1024986076978217057, 'hbsj002', '长孙杰', 1024980634071852417, 1024707535891944769, NULL, '13987675455', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:08:44', 1, '2022-09-29 10:08:44');
INSERT INTO `itcast_auth_user` VALUES (1024986455853892225, 'bjsj002', '漼时宜', 1024980728632436289, 1024707535891944769, NULL, '17898989565', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:10:15', 1, '2022-09-29 10:10:15');
INSERT INTO `itcast_auth_user` VALUES (1024987310187482529, 'bjsj001', '宏晓誉', 1024980728632436289, 1024707535891944769, NULL, '18737437483', 'M', b'1', '', '', '2022-09-29 17:58:14', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:13:38', 1, '2022-09-29 10:13:38');
INSERT INTO `itcast_auth_user` VALUES (1024987378881793537, 'sysj001', '司沈阳', 1024984540818568481, 1024707535891944769, NULL, '13311111222', 'M', b'1', '', '', '2022-09-29 15:51:15', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, 1024705709255773345, b'0', 1, '2022-09-29 10:13:55', 1, '2022-09-29 10:52:15');
INSERT INTO `itcast_auth_user` VALUES (1024987860782158145, 'sykdy001', '顺意', 1024980833938827105, 1024707516816250081, NULL, '18734736473', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:15:50', 1, '2022-09-29 10:15:50');
INSERT INTO `itcast_auth_user` VALUES (1024987931753976513, 'sykdy002', '顺心', 1024980833938827105, 1024707516816250081, NULL, '17647657465', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:16:06', 1, '2022-09-29 10:16:06');
INSERT INTO `itcast_auth_user` VALUES (1024988097613534273, 'cpkdy001', '景昌', 1024980800111765185, 1024707516816250081, NULL, '18784574758', 'M', b'1', '', '', '2022-10-13 14:44:28', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:16:46', 1, '2022-09-29 10:16:46');
INSERT INTO `itcast_auth_user` VALUES (1024988171324232993, 'cpkdy002', '景元', 1024980800111765185, 1024707516816250081, NULL, '18783748374', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:17:04', 1, '2022-09-29 10:17:04');
INSERT INTO `itcast_auth_user` VALUES (1024988319861315553, 'hpkdy001', '李和平', 1024985257948084801, 1024707516816250081, NULL, '13355554444', 'M', b'1', '', '', '2022-09-30 15:21:11', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:17:39', 1, '2022-09-29 11:39:17');
INSERT INTO `itcast_auth_user` VALUES (1024988498702245281, 'hpkdy002', '李平和', 1024985257948084801, 1024707516816250081, NULL, '17788889999', 'M', b'1', '', '', '2022-10-11 13:30:16', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:18:22', 1, '2022-09-29 11:39:23');
INSERT INTO `itcast_auth_user` VALUES (1024988744815617761, 'gukdy001', '李姑皇', 1024985129287809409, 1024707516816250081, NULL, '17766667777', 'M', b'1', '', '', '2022-10-17 17:34:12', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:19:20', 1, '2022-09-30 17:50:52');
INSERT INTO `itcast_auth_user` VALUES (1024989856838856577, 'hgkdy002', '李皇姑', 1024985129287809409, 1024707516816250081, NULL, '18877776666', 'M', b'1', '', '', '2022-10-17 17:34:23', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:23:45', 1, '2022-09-30 18:28:37');
INSERT INTO `itcast_auth_user` VALUES (1024994498993865153, 'hzsj', '司华中', 1024990726519403457, 1024707535891944769, NULL, '18877776666', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:42:12', 1, '2022-09-29 10:42:12');
INSERT INTO `itcast_auth_user` VALUES (1024994711959651169, 'whsj', '司武汉', 1024991961163118369, 1024707535891944769, NULL, '17788887777', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:43:03', 1, '2022-09-29 10:43:03');
INSERT INTO `itcast_auth_user` VALUES (1024995063794648993, 'jhkdy001', '李江汉', 1024993548853984385, 1024707516816250081, NULL, '17799990000', 'M', b'1', '', '', '2022-10-18 16:03:23', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:44:27', 1, '2022-09-29 10:44:27');
INSERT INTO `itcast_auth_user` VALUES (1024995257768626273, 'jhkdy002', '李汉江', 1024993548853984385, 1024707516816250081, NULL, '17788882222', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:45:13', 1, '2022-09-30 17:50:34');
INSERT INTO `itcast_auth_user` VALUES (1024995991193013985, 'wckdy001', '李武昌', 1024993422324415489, 1024707516816250081, NULL, '18877778888', 'M', b'1', '', '', '2022-09-29 17:37:30', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:48:08', 1, '2022-09-29 10:48:08');
INSERT INTO `itcast_auth_user` VALUES (1024996147695079329, 'wckdy002', '李昌武', 1024993422324415489, 1024707516816250081, NULL, '18877776666', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:48:45', 1, '2022-09-29 10:48:45');
INSERT INTO `itcast_auth_user` VALUES (1024997316655995489, 'dbsj', '司东北', 1024982867475820033, 1024707535891944769, NULL, '17788887777', 'M', b'1', '', '', '2022-09-30 16:09:56', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 10:53:24', 1, '2022-09-29 10:53:24');
INSERT INTO `itcast_auth_user` VALUES (1025074399029692449, 'hpkdy003', '王和平', 1024985257948084801, 1024707516816250081, NULL, '17788887777', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 15:59:42', 1, '2022-09-29 15:59:42');
INSERT INTO `itcast_auth_user` VALUES (1025104059952247329, 'hnsj001', '司华南', 1025103176946395585, 1024707535891944769, NULL, '17788887777', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 17:57:34', 1, '2022-09-29 17:57:34');
INSERT INTO `itcast_auth_user` VALUES (1025104550799061921, 'szsj001', '司深圳', 1025103512826260673, 1024707535891944769, NULL, '18877776666', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 17:59:31', 1, '2022-09-29 17:59:40');
INSERT INTO `itcast_auth_user` VALUES (1025109259005971617, 'gmkdy001', '王光明', 1025108643500246881, 1024707516816250081, NULL, '18877776666', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 18:18:13', 1, '2022-09-29 18:18:13');
INSERT INTO `itcast_auth_user` VALUES (1025110041134617825, 'bakdy001', '王保安', 1025108572721366561, 1024707516816250081, NULL, '18877776666', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 18:21:20', 1, '2022-09-29 18:21:20');
INSERT INTO `itcast_auth_user` VALUES (1025110490961140193, 'gmkdy002', '王明光', 1025108643500246881, 1024707516816250081, NULL, '16677779999', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 18:23:07', 1, '2022-09-29 18:23:07');
INSERT INTO `itcast_auth_user` VALUES (1025110675888003969, 'bakdy002', '王安宝', 1025108572721366561, 1024707516816250081, NULL, '16677776666', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 18:23:51', 1, '2022-09-29 18:23:51');
INSERT INTO `itcast_auth_user` VALUES (1025110935532199265, 'yxkdy001', '王越秀', 1025108784911206497, 1024707516816250081, NULL, '16688886666', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 18:24:53', 1, '2022-09-29 18:24:53');
INSERT INTO `itcast_auth_user` VALUES (1025111112225644097, 'hdkdy001', '王华都', 1025108696675633121, 1024707516816250081, NULL, '17799995555', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 18:25:35', 1, '2022-09-29 18:25:35');
INSERT INTO `itcast_auth_user` VALUES (1025111247919767297, 'hdkdy002', '王都花', 1025108696675633121, 1024707516816250081, NULL, '16677776666', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 18:26:07', 1, '2022-09-29 18:26:07');
INSERT INTO `itcast_auth_user` VALUES (1025111573938823425, 'yxkdy002', '王秀越', 1025108784911206497, 1024707516816250081, NULL, '17788887777', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 18:27:25', 1, '2022-09-29 18:27:25');
INSERT INTO `itcast_auth_user` VALUES (1025112013736764417, 'gzsj', '司广州', 1025103442882046977, 1024707535891944769, NULL, '18877770000', 'M', b'1', '', '', '2022-10-17 11:19:58', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-29 18:29:10', 1, '2022-09-29 18:29:10');
INSERT INTO `itcast_auth_user` VALUES (1025428687312684929, 'sl001', '张成飞', 1024704844486756641, 1024705489436494721, NULL, '18866666666', 'M', b'1', '', '', '2022-10-14 09:09:16', 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-09-30 15:27:31', 1, '2022-10-06 09:50:38');
INSERT INTO `itcast_auth_user` VALUES (1027527374507700225, 'sldd001', '张调马', 1024980958136362977, 1024705489436494721, NULL, '13111332426', 'M', b'1', '', '', NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', NULL, -1, b'0', 1, '2022-10-06 10:26:57', 1, '2022-10-06 10:26:57');

-- ----------------------------
-- Table structure for itcast_auth_user_group
-- ----------------------------
DROP TABLE IF EXISTS `itcast_auth_user_group`;
CREATE TABLE `itcast_auth_user_group`  (
  `id` bigint NOT NULL,
  `name` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '用户组名称',
  `user_count` int NOT NULL COMMENT '用户数量',
  `role_id` bigint NOT NULL COMMENT '角色id',
  `describe_` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '功能描述',
  `status` bit(1) NULL DEFAULT b'1' COMMENT '状态',
  `create_user` bigint NULL DEFAULT 0 COMMENT '创建人id',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  `update_user` bigint NULL DEFAULT 0 COMMENT '更新人id',
  `update_time` datetime NULL DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `user_group_name`(`name` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '用户组' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of itcast_auth_user_group
-- ----------------------------

-- ----------------------------
-- Table structure for itcast_auth_user_group_user
-- ----------------------------
DROP TABLE IF EXISTS `itcast_auth_user_group_user`;
CREATE TABLE `itcast_auth_user_group_user`  (
  `id` bigint NOT NULL,
  `group_id` bigint NOT NULL DEFAULT 0 COMMENT '用户组ID',
  `user_id` bigint NOT NULL DEFAULT 0 COMMENT '用户ID',
  `create_user` bigint NULL DEFAULT NULL COMMENT '创建人ID',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IDX_KEY`(`group_id` ASC, `user_id` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '用户组、用户绑定' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of itcast_auth_user_group_user
-- ----------------------------

-- ----------------------------
-- Table structure for itcast_auth_user_role
-- ----------------------------
DROP TABLE IF EXISTS `itcast_auth_user_role`;
CREATE TABLE `itcast_auth_user_role`  (
  `id` bigint NOT NULL,
  `role_id` bigint NOT NULL DEFAULT 0 COMMENT '角色ID\n#c_auth_role',
  `user_id` bigint NOT NULL DEFAULT 0 COMMENT '用户ID\n#c_core_accou',
  `type` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0用户 1 用户组',
  `application_id` bigint NULL DEFAULT NULL COMMENT '应用id',
  `create_user` bigint NULL DEFAULT NULL COMMENT '创建人ID',
  `create_time` datetime NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IDX_KEY`(`role_id` ASC, `user_id` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '角色分配\r\n账号角色绑定' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of itcast_auth_user_role
-- ----------------------------
INSERT INTO `itcast_auth_user_role` VALUES (1024747438847658017, 989559028277315009, 1024738594893428865, 0, 981194468570960001, 1, '2022-09-28 18:20:29');
INSERT INTO `itcast_auth_user_role` VALUES (1024747457927547105, 989559028277315009, 1024738476802799553, 0, 981194468570960001, 1, '2022-09-28 18:20:33');
INSERT INTO `itcast_auth_user_role` VALUES (1024747540928629665, 989559028277315009, 1024742403489234657, 0, 981194468570960001, 1, '2022-09-28 18:20:53');
INSERT INTO `itcast_auth_user_role` VALUES (1024747558616009825, 989559028277315009, 1024742265953811937, 0, 981194468570960001, 1, '2022-09-28 18:20:57');
INSERT INTO `itcast_auth_user_role` VALUES (1024747576802512161, 989559028277315009, 1024742117286706369, 0, 981194468570960001, 1, '2022-09-28 18:21:01');
INSERT INTO `itcast_auth_user_role` VALUES (1024747598537395681, 989559028277315009, 1024741978908228513, 0, 981194468570960001, 1, '2022-09-28 18:21:07');
INSERT INTO `itcast_auth_user_role` VALUES (1024977845987957281, 989559057641637825, 1024977719693268993, 0, 981194468570960001, 1, '2022-09-29 09:36:02');
INSERT INTO `itcast_auth_user_role` VALUES (1024977876967086817, 989559057641637825, 1024977621806601633, 0, 981194468570960001, 1, '2022-09-29 09:36:09');
INSERT INTO `itcast_auth_user_role` VALUES (1024977896483183521, 989559057641637825, 1024977522992993473, 0, 981194468570960001, 1, '2022-09-29 09:36:14');
INSERT INTO `itcast_auth_user_role` VALUES (1024977916334824545, 989559057641637825, 1024977388880122881, 0, 981194468570960001, 1, '2022-09-29 09:36:19');
INSERT INTO `itcast_auth_user_role` VALUES (1024977939541908769, 989559057641637825, 1024977221418341025, 0, 981194468570960001, 1, '2022-09-29 09:36:24');
INSERT INTO `itcast_auth_user_role` VALUES (1024977988497825441, 989559057641637825, 1024977078208025057, 0, 981194468570960001, 1, '2022-09-29 09:36:36');
INSERT INTO `itcast_auth_user_role` VALUES (1024978009800695649, 989559057641637825, 1024976941658263777, 0, 981194468570960001, 1, '2022-09-29 09:36:41');
INSERT INTO `itcast_auth_user_role` VALUES (1024978040662384673, 989559028277315009, 1024976605161836353, 0, 981194468570960001, 1, '2022-09-29 09:36:48');
INSERT INTO `itcast_auth_user_role` VALUES (1024978061000564961, 989559057641637825, 1024976781221941281, 0, 981194468570960001, 1, '2022-09-29 09:36:53');
INSERT INTO `itcast_auth_user_role` VALUES (1024978084153123233, 989559028277315009, 1024976390379916929, 0, 981194468570960001, 1, '2022-09-29 09:36:59');
INSERT INTO `itcast_auth_user_role` VALUES (1024988398319966657, 989559057641637825, 1024985481462545409, 0, 981194468570960001, 1, '2022-09-29 10:17:58');
INSERT INTO `itcast_auth_user_role` VALUES (1024988418788170401, 989559057641637825, 1024985344870841121, 0, 981194468570960001, 1, '2022-09-29 10:18:03');
INSERT INTO `itcast_auth_user_role` VALUES (1024988436408441697, 989559057641637825, 1024984891772761697, 0, 981194468570960001, 1, '2022-09-29 10:18:07');
INSERT INTO `itcast_auth_user_role` VALUES (1024988455681268769, 989559057641637825, 1024984720745821569, 0, 981194468570960001, 1, '2022-09-29 10:18:11');
INSERT INTO `itcast_auth_user_role` VALUES (1024988484508720353, 989559028277315009, 1024984516357387297, 0, 981194468570960001, 1, '2022-09-29 10:18:18');
INSERT INTO `itcast_auth_user_role` VALUES (1024988510177861121, 989559028277315009, 1024984365991588705, 0, 981194468570960001, 1, '2022-09-29 10:18:24');
INSERT INTO `itcast_auth_user_role` VALUES (1024988527454199489, 989559028277315009, 1024984230121304705, 0, 981194468570960001, 1, '2022-09-29 10:18:29');
INSERT INTO `itcast_auth_user_role` VALUES (1024988548929036161, 989559028277315009, 1024984140988150081, 0, 981194468570960001, 1, '2022-09-29 10:18:34');
INSERT INTO `itcast_auth_user_role` VALUES (1024988600422506817, 989559057641637825, 1024988171324232993, 0, 981194468570960001, 1, '2022-09-29 10:18:46');
INSERT INTO `itcast_auth_user_role` VALUES (1024988621943480833, 989559057641637825, 1024988097613534273, 0, 981194468570960001, 1, '2022-09-29 10:18:51');
INSERT INTO `itcast_auth_user_role` VALUES (1024988638016053953, 989559057641637825, 1024987931753976513, 0, 981194468570960001, 1, '2022-09-29 10:18:55');
INSERT INTO `itcast_auth_user_role` VALUES (1024988665618768769, 989559057641637825, 1024987860782158145, 0, 981194468570960001, 1, '2022-09-29 10:19:01');
INSERT INTO `itcast_auth_user_role` VALUES (1024988686183441473, 989559028277315009, 1024987310187482529, 0, 981194468570960001, 1, '2022-09-29 10:19:06');
INSERT INTO `itcast_auth_user_role` VALUES (1024988703958902017, 989559028277315009, 1024986455853892225, 0, 981194468570960001, 1, '2022-09-29 10:19:11');
INSERT INTO `itcast_auth_user_role` VALUES (1024988730609509921, 989559028277315009, 1024986076978217057, 0, 981194468570960001, 1, '2022-09-29 10:19:17');
INSERT INTO `itcast_auth_user_role` VALUES (1024988748829566785, 989559028277315009, 1024985621531327777, 0, 981194468570960001, 1, '2022-09-29 10:19:21');
INSERT INTO `itcast_auth_user_role` VALUES (1024997918857387169, 989559057641637825, 1024996147695079329, 0, 981194468570960001, 1, '2022-09-29 10:55:48');
INSERT INTO `itcast_auth_user_role` VALUES (1024997945814179169, 989559057641637825, 1024995991193013985, 0, 981194468570960001, 1, '2022-09-29 10:55:54');
INSERT INTO `itcast_auth_user_role` VALUES (1024998002189819617, 989559057641637825, 1024995063794648993, 0, 981194468570960001, 1, '2022-09-29 10:56:07');
INSERT INTO `itcast_auth_user_role` VALUES (1024998084700168481, 989559028277315009, 1024994498993865153, 0, 981194468570960001, 1, '2022-09-29 10:56:27');
INSERT INTO `itcast_auth_user_role` VALUES (1024998137774891521, 989559028277315009, 1024997316655995489, 0, 981194468570960001, 1, '2022-09-29 10:56:40');
INSERT INTO `itcast_auth_user_role` VALUES (1024998244062750273, 989559028277315009, 1024987378881793537, 0, 981194468570960001, 1, '2022-09-29 10:57:05');
INSERT INTO `itcast_auth_user_role` VALUES (1025073317381603905, 989559028277315009, 1024994711959651169, 0, 981194468570960001, 1, '2022-09-29 15:55:24');
INSERT INTO `itcast_auth_user_role` VALUES (1025074469976344993, 989559057641637825, 1025074399029692449, 0, 981194468570960001, 1, '2022-09-29 15:59:59');
INSERT INTO `itcast_auth_user_role` VALUES (1025075950653742945, 989559057641637825, 1024988498702245281, 0, 981194468570960001, 1, '2022-09-29 16:05:52');
INSERT INTO `itcast_auth_user_role` VALUES (1025076031935160641, 989559057641637825, 1024988319861315553, 0, 981194468570960001, 1, '2022-09-29 16:06:11');
INSERT INTO `itcast_auth_user_role` VALUES (1025105315110304449, 989559028277315009, 1025104550799061921, 0, 981194468570960001, 1, '2022-09-29 18:02:33');
INSERT INTO `itcast_auth_user_role` VALUES (1025105333720431489, 989559028277315009, 1025104059952247329, 0, 981194468570960001, 1, '2022-09-29 18:02:37');
INSERT INTO `itcast_auth_user_role` VALUES (1025112177083934305, 989559028277315009, 1025112013736764417, 0, 981194468570960001, 1, '2022-09-29 18:29:49');
INSERT INTO `itcast_auth_user_role` VALUES (1025112260739328065, 989559057641637825, 1025111573938823425, 0, 981194468570960001, 1, '2022-09-29 18:30:09');
INSERT INTO `itcast_auth_user_role` VALUES (1025112283925440769, 989559057641637825, 1025111247919767297, 0, 981194468570960001, 1, '2022-09-29 18:30:14');
INSERT INTO `itcast_auth_user_role` VALUES (1025112302535567809, 989559057641637825, 1025111112225644097, 0, 981194468570960001, 1, '2022-09-29 18:30:19');
INSERT INTO `itcast_auth_user_role` VALUES (1025112322601118337, 989559057641637825, 1025110935532199265, 0, 981194468570960001, 1, '2022-09-29 18:30:24');
INSERT INTO `itcast_auth_user_role` VALUES (1025112346047277889, 989559057641637825, 1025110675888003969, 0, 981194468570960001, 1, '2022-09-29 18:30:29');
INSERT INTO `itcast_auth_user_role` VALUES (1025112364095368193, 989559057641637825, 1025110490961140193, 0, 981194468570960001, 1, '2022-09-29 18:30:33');
INSERT INTO `itcast_auth_user_role` VALUES (1025112383267531969, 989559057641637825, 1025110041134617825, 0, 981194468570960001, 1, '2022-09-29 18:30:38');
INSERT INTO `itcast_auth_user_role` VALUES (1025112405220519297, 989559057641637825, 1025109259005971617, 0, 981194468570960001, 1, '2022-09-29 18:30:43');
INSERT INTO `itcast_auth_user_role` VALUES (1025354337846829025, 986227712144197857, 1024705709255773345, 0, 981194468570960001, 1, '2022-09-30 10:32:05');
INSERT INTO `itcast_auth_user_role` VALUES (1025428973724928321, 986227712144197857, 1025428687312684929, 0, 981194468570960001, 1, '2022-09-30 15:28:39');
INSERT INTO `itcast_auth_user_role` VALUES (1025473170561639681, 989559057641637825, 1024988744815617761, 0, 981194468570960001, 1, '2022-09-30 18:24:16');
INSERT INTO `itcast_auth_user_role` VALUES (1025474047024375873, 989559057641637825, 1024989856838856577, 0, 981194468570960001, 1, '2022-09-30 18:27:45');
INSERT INTO `itcast_auth_user_role` VALUES (1027518139778549345, 989559057641637825, 1024995257768626273, 0, 981194468570960001, 1, '2022-10-06 09:50:15');
INSERT INTO `itcast_auth_user_role` VALUES (1027527680985495073, 996045927523359809, 1027527374507700225, 0, 981194468570960001, 1, '2022-10-06 10:28:10');

-- ----------------------------
-- Table structure for itcast_common_login_log
-- ----------------------------
DROP TABLE IF EXISTS `itcast_common_login_log`;
CREATE TABLE `itcast_common_login_log`  (
  `id` bigint NOT NULL COMMENT '主键',
  `request_ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '操作IP',
  `user_id` bigint NULL DEFAULT NULL COMMENT '登录人ID',
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '登录人姓名',
  `account` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '登录人账号',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '登录描述',
  `login_date` date NULL DEFAULT NULL COMMENT '登录时间',
  `ua` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '0' COMMENT '浏览器请求头',
  `browser` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '浏览器名称',
  `browser_version` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '浏览器版本',
  `operating_system` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '操作系统',
  `location` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '登录地点',
  `create_time` datetime NULL DEFAULT NULL,
  `create_user` bigint NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `IDX_BROWSER`(`browser` ASC) USING BTREE,
  INDEX `IDX_OPERATING`(`operating_system` ASC) USING BTREE,
  INDEX `IDX_LOGIN_DATE`(`login_date` ASC, `account` ASC) USING BTREE,
  INDEX `IDX_ACCOUNT_IP`(`account` ASC, `request_ip` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '登录日志' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of itcast_common_login_log
-- ----------------------------

-- ----------------------------
-- Table structure for itcast_common_opt_log
-- ----------------------------
DROP TABLE IF EXISTS `itcast_common_opt_log`;
CREATE TABLE `itcast_common_opt_log`  (
  `id` bigint NOT NULL COMMENT '主键',
  `request_ip` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '操作IP',
  `type` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'OPT' COMMENT '日志类型\n#LogType{OPT:操作类型;EX:异常类型}',
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '操作人',
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '操作描述',
  `class_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '类路径',
  `action_method` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '请求方法',
  `request_uri` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '请求地址',
  `http_method` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT 'GET' COMMENT '请求类型\n#HttpMethod{GET:GET请求;POST:POST请求;PUT:PUT请求;DELETE:DELETE请求;PATCH:PATCH请求;TRACE:TRACE请求;HEAD:HEAD请求;OPTIONS:OPTIONS请求;}',
  `params` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '请求参数',
  `result` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '返回值',
  `ex_desc` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '异常详情信息',
  `ex_detail` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL COMMENT '异常描述',
  `start_time` timestamp NULL DEFAULT NULL COMMENT '开始时间',
  `finish_time` timestamp NULL DEFAULT NULL COMMENT '完成时间',
  `consuming_time` bigint NULL DEFAULT 0 COMMENT '消耗时间',
  `ua` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '浏览器',
  `create_time` datetime NULL DEFAULT NULL,
  `create_user` bigint NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `index_type`(`type` ASC) USING BTREE COMMENT '日志类型'
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '系统日志' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of itcast_common_opt_log
-- ----------------------------

-- ----------------------------
-- Table structure for itcast_core_org
-- ----------------------------
DROP TABLE IF EXISTS `itcast_core_org`;
CREATE TABLE `itcast_core_org`  (
  `id` bigint NOT NULL COMMENT 'ID',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '名称',
  `abbreviation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '简称',
  `parent_id` bigint NULL DEFAULT 0 COMMENT '父ID',
  `org_type` tinyint(1) NULL DEFAULT NULL COMMENT '部门类型 1为分公司，2为一级转运中心 3为二级转运中心 4为网点',
  `province_id` bigint NULL DEFAULT NULL COMMENT '省',
  `city_id` bigint NULL DEFAULT NULL COMMENT '市',
  `county_id` bigint NULL DEFAULT NULL COMMENT '区',
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '地址',
  `contract_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL COMMENT '联系电话',
  `manager_id` bigint NULL DEFAULT NULL COMMENT '负责人id',
  `tree_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT ',' COMMENT '树结构',
  `sort_value` int NULL DEFAULT 1 COMMENT '排序',
  `status` bit(1) NULL DEFAULT b'0' COMMENT '状态',
  `describe_` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '描述',
  `create_time` datetime NULL DEFAULT NULL,
  `create_user` bigint NULL DEFAULT NULL,
  `update_time` datetime NULL DEFAULT NULL,
  `update_user` bigint NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `PCO_NAME`(`name` ASC) USING BTREE,
  FULLTEXT INDEX `FU_PATH`(`tree_path`)
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '组织' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of itcast_core_org
-- ----------------------------
INSERT INTO `itcast_core_org` VALUES (1024704844486756641, '西北转运中心', '', 0, NULL, NULL, NULL, NULL, NULL, NULL, 1, ',', 0, b'1', '', '2022-09-28 15:31:13', 1, '2022-09-28 15:31:13', 1);
INSERT INTO `itcast_core_org` VALUES (1024706655985685345, '西南转运中心', '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',', 0, b'1', '', '2022-09-28 15:38:25', 1, '2022-09-28 15:38:25', 1);
INSERT INTO `itcast_core_org` VALUES (1024706903290237921, '成都分拣中心', '', 1024706655985685345, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1024706655985685345,', 0, b'1', '', '2022-09-28 15:39:24', 1, '2022-09-28 15:39:24', 1);
INSERT INTO `itcast_core_org` VALUES (1024771466287232801, '金牛区营业部', '', 1024706903290237921, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1024706655985685345,1024706903290237921,', 0, b'1', '', '2022-09-28 19:55:57', 1, '2022-09-28 19:55:57', 1);
INSERT INTO `itcast_core_org` VALUES (1024771753995515873, '青羊区营业部', '', 1024706903290237921, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1024706655985685345,1024706903290237921,', 0, b'1', '', '2022-09-28 19:57:06', 1, '2022-09-28 19:57:06', 1);
INSERT INTO `itcast_core_org` VALUES (1024772115791985729, '西安分拣中心', '', 1024704844486756641, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1024704844486756641,', 0, b'1', '', '2022-09-28 19:58:32', 1, '2022-09-28 19:58:32', 1);
INSERT INTO `itcast_core_org` VALUES (1024772301733870785, '碑林区营业部', '', 1024772115791985729, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1024704844486756641,1024772115791985729,', 0, b'1', '', '2022-09-28 19:59:16', 1, '2022-09-28 19:59:16', 1);
INSERT INTO `itcast_core_org` VALUES (1024772425923018049, '长安区营业部', '', 1024772115791985729, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1024704844486756641,1024772115791985729,', 0, b'1', '', '2022-09-28 19:59:46', 1, '2022-09-28 19:59:46', 1);
INSERT INTO `itcast_core_org` VALUES (1024980634071852417, '华北转运中心', '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',', 0, b'1', '', '2022-09-29 09:47:07', 1, '2022-09-29 09:47:07', 1);
INSERT INTO `itcast_core_org` VALUES (1024980728632436289, '北京分拣中心', '', 1024980634071852417, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1024980634071852417,', 0, b'1', '', '2022-09-29 09:47:29', 1, '2022-09-29 09:47:29', 1);
INSERT INTO `itcast_core_org` VALUES (1024980800111765185, '昌平区营业部', '', 1024980728632436289, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1024980634071852417,1024980728632436289,', 0, b'1', '', '2022-09-29 09:47:46', 1, '2022-09-29 09:47:46', 1);
INSERT INTO `itcast_core_org` VALUES (1024980833938827105, '顺义区营业部', '', 1024980728632436289, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1024980634071852417,1024980728632436289,', 0, b'1', '', '2022-09-29 09:47:54', 1, '2022-09-29 09:47:54', 1);
INSERT INTO `itcast_core_org` VALUES (1024980958136362977, '华东转运中心', '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',', 0, b'1', '', '2022-09-29 09:48:24', 1, '2022-09-29 09:48:24', 1);
INSERT INTO `itcast_core_org` VALUES (1024980990084376673, '上海分拣中心', '', 1024980958136362977, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1024980958136362977,', 0, b'1', '', '2022-09-29 09:48:31', 1, '2022-09-29 09:48:31', 1);
INSERT INTO `itcast_core_org` VALUES (1024981239465110017, '浦东新区营业部', '', 1024980990084376673, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1024980958136362977,1024980990084376673,', 0, b'1', '', '2022-09-29 09:49:31', 1, '2022-09-29 09:49:31', 1);
INSERT INTO `itcast_core_org` VALUES (1024981295454874273, '虹口区营业部', '', 1024980990084376673, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1024980958136362977,1024980990084376673,', 0, b'1', '', '2022-09-29 09:49:44', 1, '2022-09-29 09:49:44', 1);
INSERT INTO `itcast_core_org` VALUES (1024982867475820033, '东北转运中心', '', 0, NULL, NULL, NULL, NULL, NULL, NULL, 1024705709255773345, ',', 1, b'1', '', '2022-09-29 09:55:59', 1, '2022-09-29 09:55:59', 1);
INSERT INTO `itcast_core_org` VALUES (1024984540818568481, '沈阳分拣中心', '', 1024982867475820033, NULL, NULL, NULL, NULL, NULL, NULL, 1024705709255773345, ',1024982867475820033,', 0, b'1', '', '2022-09-29 10:02:38', 1, '2022-09-29 10:02:38', 1);
INSERT INTO `itcast_core_org` VALUES (1024985129287809409, '皇姑区营业部', '', 1024984540818568481, NULL, NULL, NULL, NULL, NULL, NULL, 1024705709255773345, ',1024982867475820033,1024984540818568481,', 0, b'1', '', '2022-09-29 10:04:58', 1, '2022-09-29 10:04:58', 1);
INSERT INTO `itcast_core_org` VALUES (1024985257948084801, '和平区营业部', '', 1024984540818568481, NULL, NULL, NULL, NULL, NULL, NULL, 1024705709255773345, ',1024982867475820033,1024984540818568481,', 0, b'1', '', '2022-09-29 10:05:29', 1, '2022-09-29 10:05:29', 1);
INSERT INTO `itcast_core_org` VALUES (1024990726519403457, '华中转运中心', '', 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',', 0, b'1', '', '2022-09-29 10:27:13', 1, '2022-09-29 10:27:13', 1);
INSERT INTO `itcast_core_org` VALUES (1024991961163118369, '武汉分拣中心', '', 1024990726519403457, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1024990726519403457,', 0, b'1', '', '2022-09-29 10:32:07', 1, '2022-09-29 10:32:07', 1);
INSERT INTO `itcast_core_org` VALUES (1024993422324415489, '武昌营业部', '', 1024991961163118369, NULL, NULL, NULL, NULL, NULL, NULL, 1024705709255773345, ',1024990726519403457,1024991961163118369,', 0, b'1', '', '2022-09-29 10:37:56', 1, '2022-09-29 10:37:56', 1);
INSERT INTO `itcast_core_org` VALUES (1024993548853984385, '江汉营业部', '', 1024991961163118369, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1024990726519403457,1024991961163118369,', 0, b'1', '', '2022-09-29 10:38:26', 1, '2022-09-29 10:38:26', 1);
INSERT INTO `itcast_core_org` VALUES (1025103176946395585, '华南转运中心', '', 0, NULL, NULL, NULL, NULL, NULL, NULL, 1024705709255773345, ',', 0, b'1', '', '2022-09-29 17:54:03', 1, '2022-09-29 17:54:03', 1);
INSERT INTO `itcast_core_org` VALUES (1025103442882046977, '广州分拣中心', '', 1025103176946395585, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1025103176946395585,', 0, b'1', '', '2022-09-29 17:55:06', 1, '2022-09-29 17:55:06', 1);
INSERT INTO `itcast_core_org` VALUES (1025103512826260673, '深圳分拣中心', '', 1025103176946395585, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1025103176946395585,', 0, b'1', '', '2022-09-29 17:55:23', 1, '2022-09-29 17:55:23', 1);
INSERT INTO `itcast_core_org` VALUES (1025108572721366561, ' 宝安区营业部', '', 1025103512826260673, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1025103176946395585,1025103512826260673,', 0, b'1', '', '2022-09-29 18:15:30', 1, '2022-09-29 18:15:30', 1);
INSERT INTO `itcast_core_org` VALUES (1025108643500246881, '光明区营业部', '', 1025103512826260673, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1025103176946395585,1025103512826260673,', 0, b'1', '', '2022-09-29 18:15:46', 1, '2022-09-29 18:15:46', 1);
INSERT INTO `itcast_core_org` VALUES (1025108696675633121, '花都营业部', '', 1025103442882046977, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1025103176946395585,1025103442882046977,', 0, b'1', '', '2022-09-29 18:15:59', 1, '2022-09-29 18:15:59', 1);
INSERT INTO `itcast_core_org` VALUES (1025108784911206497, '越秀区营业部', '', 1025103442882046977, NULL, NULL, NULL, NULL, NULL, NULL, NULL, ',1025103176946395585,1025103442882046977,', 0, b'1', '', '2022-09-29 18:16:20', 1, '2022-09-29 18:16:20', 1);

-- ----------------------------
-- Table structure for itcast_core_station
-- ----------------------------
DROP TABLE IF EXISTS `itcast_core_station`;
CREATE TABLE `itcast_core_station`  (
  `id` bigint NOT NULL COMMENT 'ID',
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '' COMMENT '名称',
  `org_id` bigint NULL DEFAULT 0 COMMENT '组织ID\n#c_core_org',
  `status` bit(1) NULL DEFAULT b'1' COMMENT '状态',
  `describe_` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '' COMMENT '描述',
  `create_time` datetime NULL DEFAULT NULL,
  `create_user` bigint NULL DEFAULT NULL,
  `update_time` datetime NULL DEFAULT NULL,
  `update_user` bigint NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `PCS_NAME`(`name` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci COMMENT = '岗位' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of itcast_core_station
-- ----------------------------
INSERT INTO `itcast_core_station` VALUES (1024705489436494721, '神领管理员', 0, b'1', '', '2022-09-28 15:33:47', 1, '2022-09-28 15:33:47', 1);
INSERT INTO `itcast_core_station` VALUES (1024707516816250081, '快递员', 0, b'1', '', '2022-09-28 15:41:50', 1, '2022-09-28 15:41:50', 1);
INSERT INTO `itcast_core_station` VALUES (1024707535891944769, '司机', 0, b'1', '', '2022-09-28 15:41:55', 1, '2022-09-28 15:41:55', 1);

SET FOREIGN_KEY_CHECKS = 1;
