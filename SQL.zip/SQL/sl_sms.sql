/*
 Navicat Premium Data Transfer

 Source Server         : 192.168.150.101-mysql
 Source Server Type    : MySQL
 Source Server Version : 80029 (8.0.29)
 Source Host           : 192.168.150.101:3306
 Source Schema         : sl_sms

 Target Server Type    : MySQL
 Target Server Version : 80029 (8.0.29)
 File Encoding         : 65001

 Date: 17/09/2024 16:54:13
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for sms_record
-- ----------------------------
DROP TABLE IF EXISTS `sms_record`;
CREATE TABLE `sms_record`  (
  `id` bigint NOT NULL COMMENT '短信发送记录id',
  `mobile` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '手机号',
  `user_id` bigint NOT NULL COMMENT '发送者唯一id',
  `third_channel_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '发送第三方的平台code',
  `verify_code` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '短信验证码',
  `bussiness_type` int NOT NULL COMMENT '业务类型,1：用户端，2：司机端，3：快递员端，4：后台管理系统',
  `sms_type` int NOT NULL COMMENT '短信类型,1:文字短信，2：语音短信',
  `content_type` int NOT NULL COMMENT '内容类型，1：短信验证码，2：营销短信',
  `batch_id` bigint NOT NULL COMMENT '发送批次id，用于判断这些数据是同一批次发送的',
  `created` datetime NOT NULL COMMENT '创建时间',
  `updated` datetime NOT NULL COMMENT '更新时间',
  `creater` bigint NOT NULL COMMENT '创建者',
  `updater` bigint NOT NULL COMMENT '更新者',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `index_created`(`created` ASC) USING BTREE,
  INDEX `index_updated`(`updated` ASC) USING BTREE,
  INDEX `index_user_id`(`user_id` ASC) USING BTREE,
  INDEX `index_batch_id`(`batch_id` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '短信发送记录' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sms_record
-- ----------------------------

-- ----------------------------
-- Table structure for sms_third_channel
-- ----------------------------
DROP TABLE IF EXISTS `sms_third_channel`;
CREATE TABLE `sms_third_channel`  (
  `id` bigint NOT NULL COMMENT '主键id',
  `bussiness_type` int NOT NULL COMMENT '业务类型type，1：用户端，2：司机端，3：快递员端，4：后台管理系统',
  `sms_type` int NOT NULL COMMENT '短信类型，1：验证类型短信，2：通知类型短信',
  `content_type` int NOT NULL COMMENT '内容类型，1:文字短信，2：语音短信',
  `sms_template` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '短信模板',
  `third_template_code` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '第三方平台模板code',
  `channel_code` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '第三方短信平台码',
  `sign_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT '签名',
  `sms_priority` int NOT NULL COMMENT '数字越大优先级越高',
  `status` int NOT NULL COMMENT '通道状态1：使用 中，2：已经停用',
  `created` datetime NOT NULL COMMENT '创建时间',
  `updated` datetime NOT NULL COMMENT '更新时间',
  `creater` bigint NOT NULL DEFAULT 0 COMMENT '创建者',
  `updater` bigint NOT NULL DEFAULT 0 COMMENT '更新者',
  `is_delete` bit(1) NOT NULL COMMENT '是否删除',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `index_created`(`created` ASC) USING BTREE,
  INDEX `index_updated`(`updated` ASC) USING BTREE,
  INDEX `index_type`(`bussiness_type` ASC, `sms_type` ASC, `content_type` ASC) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '短信发送通道' ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of sms_third_channel
-- ----------------------------

SET FOREIGN_KEY_CHECKS = 1;
